// Shared state and projection for the GPU path and the Canvas fallback.
export const PARTICLE_BURST_DURATION=2.8;
const smoothParticle=(a,b,x)=>{const t=Math.max(0,Math.min(1,(x-a)/(b-a)));return t*t*(3-2*t);};
export class ParticleChoreography {
  constructor(){this.amount=0;this.age=-1;this.hover=false;this.focus=false;this.suppressed=false;this.startAmount=0;this.orbTime=0;}
  engage(hover,focus){
    if(!this.hover&&hover&&this.age<0)this.suppressed=false;
    this.hover=hover;this.focus=focus;
  }
  input(nonempty){if(nonempty)this.suppressed=false;}
  send(time){
    if(this.age>=0)return false;
    this.startAmount=this.amount;this.orbTime=time;this.age=0;this.suppressed=true;return true;
  }
  advance(dt,enabled=true){
    if(!enabled){this.amount=0;this.age=-1;return 'field';}
    if(this.age>=0){this.age+=Math.max(0,dt);if(this.age<PARTICLE_BURST_DURATION)return 'burst';this.age=-1;this.amount=0;}
    const target=!this.suppressed&&(this.hover||this.focus)?1:0;
    const step=Math.max(0,dt)/.95;
    this.amount=Math.max(0,Math.min(1,this.amount+Math.sign(target-this.amount)*Math.min(step,Math.abs(target-this.amount))));
    return this.amount>.999?'orb':this.amount>0?'gather':'field';
  }
  uniforms(time){return {amount:smoothParticle(0,1,this.amount),age:this.age,startAmount:smoothParticle(0,1,this.startAmount),orbTime:this.age>=0?this.orbTime:time};}
}
export function projectParticleOrb(point,time,radius){
  const y=point.orbY,ring=Math.sqrt(Math.max(0,1-y*y));
  // Stable random seeds give smooth, non-repeating motion instead of frame jitter.
  // Fill a lumpy volume with several drifting density pockets, not a sphere shell.
  const seed=point.seed,group=Math.floor(seed*7),volume=.12+.88*Math.pow(seed,.42);
  const phi=point.orbPhi+time*(.12+seed*.18)+Math.sin(y*3+time*.45+seed*6)*.35;
  const warp=1+.20*Math.sin(phi*2.3+y*4-time*.45)+.12*Math.cos(phi*3.7-y*2+time*.7);
  const x=Math.cos(phi)*ring*volume*warp*(1+.10*Math.sin(time*.4))+.30*Math.sin(group*2.4+time*.27)+.06*Math.sin(seed*79+time*.83);
  const vy=y*volume*warp*.85+.22*Math.cos(group*1.7-time*.23)+.05*Math.sin(seed*53-time*.7);
  const z=Math.sin(phi)*ring*volume*warp+.25*Math.sin(group*3.1+time*.21);
  const tilt=.35+.2*Math.sin(time*.32),yy=vy*Math.cos(tilt)-z*Math.sin(tilt),zz=vy*Math.sin(tilt)+z*Math.cos(tilt);
  const perspective=3/(3-zz*.65);
  return {x:x*radius*perspective,y:yy*radius*perspective,depth:Math.max(0,Math.min(1,zz*.5+.5)),phi};
}
export function projectParticleStage(point,time,center,radius,stage,width,height){
  if(stage.amount===0&&stage.age<0)return {x:point.x,y:point.y,depth:0,phi:0,amount:0,burst:0};
  const orb=projectParticleOrb(point,stage.orbTime,radius);
  let amount=smoothParticle(point.seed*.16,1-point.seed*.12,stage.amount),x=point.x+(center.x+orb.x-point.x)*amount,y=point.y+(center.y+orb.y-point.y)*amount,burst=0;
  if(stage.age>=0){
    const startAmount=smoothParticle(point.seed*.16,1-point.seed*.12,stage.startAmount);
    burst=1-smoothParticle(1.05,PARTICLE_BURST_DURATION,stage.age);amount=startAmount*burst;
    const length=Math.max(1,Math.hypot(orb.x,orb.y)),travel=(1-Math.exp(-stage.age*2.4))*Math.hypot(width,height)*(.22+point.seed*.56);
    const spin=Math.sin(stage.age*2+point.seed*6)*stage.age*18;
    x=point.x+((center.x+orb.x-point.x)*startAmount+orb.x/length*travel-orb.y/length*spin)*burst;
    y=point.y+((center.y+orb.y-point.y)*startAmount+orb.y/length*travel+orb.x/length*spin+stage.age*stage.age*24)*burst;
  }
  return {x,y,depth:orb.depth,phi:orb.phi,amount,burst};
}
export function isParticleSendControl(button){
  if(!button||button.disabled||button.getAttribute('aria-disabled')==='true'||button.hasAttribute('data-sending')||button.getAttribute('aria-busy')==='true')return false;
  const label=button.getAttribute('aria-label')||button.getAttribute('title')||'';
  return button.hasAttribute('data-gpx-send')||/发送|\bsend\b/i.test(label);
}
