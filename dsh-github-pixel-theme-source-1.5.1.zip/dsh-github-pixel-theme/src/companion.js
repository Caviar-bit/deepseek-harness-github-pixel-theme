function conversationRoot(node) {
  const root=node?.closest?.('[data-phase="hero"],[data-phase="active"]');
  return root&&!root.closest('[data-pane="sidebar"],[data-slot="sidebar"],[data-slot="sidebar.chat"]')?root:null;
}
function readDomActivity(root,live) {
  if(!root)return 'idle';
  const has=selector=>root.querySelector(selector)!==null;
  const running=has('[data-chat-running]:not([data-holding]):not([aria-hidden="true"])')||live?.running===true;
  const streaming=[...root.querySelectorAll('[data-chat-flow-kind="assistant-step"] [data-streaming]')].some(node=>!node.closest('[data-variant="think"]'));
  // Completed historical errors are intentionally excluded from the live reading.
  if(!running&&!streaming&&live?.pendingInteraction===undefined)return 'idle';
  return classifyActivity({
    approval:live?.pendingInteraction!==undefined||has('[data-state="awaiting-approval"],[data-cordis-status="awaiting-approval"]'),
    compacting:has('[data-compacting="true"],[data-state="compacting"]'),
    conducting:has('[data-tool="spawn_agent"][data-state="running"],[data-tool="agent"][data-state="running"]'),
    tool:has('[data-chat-flow-kind="tool-call"] [data-state="running"],[data-chat-flow-kind="tool-call"][data-state="running"],[data-cordis-status="client-pending"]'),
    thinking:has('[data-variant="think"][data-state="running"]'),streaming,running
  });
}

class ClaudeCompanion {
  constructor(read,changed) {
    this.read=read;this.changed=changed;this.root=null;this.card=null;this.node=null;this.animation='';this.state='idle';this.timer=0;
    this.lastActivity=Date.now();this.lastExtra=Date.now();this.moment=null;this.reaction=null;this.started=0;
    this.userActivity=()=>{const asleep=this.node?.getAttribute('data-gpx-pet-state')==='sleeping';this.lastActivity=Date.now();if(asleep)this.play('waking',960);};
    document.addEventListener('pointerdown',this.userActivity,{passive:true});document.addEventListener('keydown',this.userActivity);
    this.place=()=>this.position();window.addEventListener?.('resize',this.place);document.addEventListener('scroll',this.place,true);
    this.visibility=()=>{if(document.hidden){clearTimeout(this.timer);this.timer=0;}else this.tick();};document.addEventListener('visibilitychange',this.visibility);
  }
  reduced(){return this.read().motion==='reduced'||matchMedia('(prefers-reduced-motion: reduce)').matches;}
  attach(card,root) {
    if(card===this.card&&root===this.root){this.position();return;}
    this.detach();this.card=card;this.root=root;this.state='idle';this.moment=null;this.reaction=null;this.lastActivity=Date.now();this.lastExtra=Date.now();
    if(!card)return;
    const node=element('div','gpx-pet'),sprite=element('span','gpx-pet-sprite'),ink=element('span','gpx-pet-ink'),hit=element('button','gpx-pet-hit');
    sprite.setAttribute('aria-hidden','true');ink.setAttribute('aria-hidden','true');hit.type='button';
    hit.addEventListener('click',event=>{event.stopPropagation();this.lastActivity=Date.now();this.play(this.state==='sleeping'?'waking':'idle-laptop',this.state==='sleeping'?960:3440);});
    hit.addEventListener('dblclick',event=>{event.stopPropagation();this.play('tickle',1280);});
    node.append(sprite,ink,hit);document.body.append(node);this.node=node;this.sprite=sprite;this.ink=ink;this.hit=hit;
    this.sizeObserver=new ResizeObserver(()=>this.position());this.sizeObserver.observe(card);if(root!==card)this.sizeObserver.observe(root);
    this.position();this.tick();
  }
  position() {
    if(!this.node||!this.card)return;
    const r=this.card.getBoundingClientRect(),scale=2*this.read().petSize/100,w=52*scale,h=36*scale;
    const viewport=window.innerWidth||document.documentElement.clientWidth||960;
    this.node.hidden=document.hidden||!this.card.isConnected||r.width<=0||r.height<=0||r.bottom<=0||r.top<h||r.top>(window.innerHeight||100000);
    this.node.style.width=w+'px';this.node.style.height=h+'px';this.node.style.left=Math.max(0,Math.min(viewport-w,r.right-w))+'px';this.node.style.top=Math.max(0,r.top-h)+'px';
    if(this.node.hidden){clearTimeout(this.timer);this.timer=0;}else if(!this.timer)this.tick();
  }
  update(state) {
    const busy=value=>!['idle','happy','error','sleeping'].includes(value);
    if(busy(this.state)&&state==='idle'&&!this.moment)this.moment={state:'happy',until:Date.now()+2560};
    if(state!=='idle'&&this.moment?.state!=='error')this.moment=null;
    this.state=state;this.position();this.tick();
  }
  error(){this.moment={state:'error',until:Date.now()+3200};this.tick();}
  play(animation,duration){this.reaction={animation,until:Date.now()+duration};this.setAnimation(animation);this.tick();}
  setAnimation(name) {
    if(this.animation===name)return;
    this.animation=name;this.started=Date.now();
    if(this.node)this.node.setAttribute('data-gpx-animation',name);
  }
  tick() {
    clearTimeout(this.timer);this.timer=0;
    if(!this.node||this.node.hidden||document.hidden)return;
    const now=Date.now();let state=this.state;
    if(this.moment&&now>=this.moment.until)this.moment=null;
    if(this.reaction&&now>=this.reaction.until)this.reaction=null;
    if(state!=='approval'&&this.moment)state=this.moment.state;
    if(state==='idle'&&now-this.lastActivity>=60000)state='sleeping';
    if(state==='idle'&&!this.reaction&&now-this.lastExtra>=14000&&!this.reduced()) {
      this.lastExtra=now;const names=['idle-look','idle-wave','idle-laptop'];const animation=names[Math.floor(Math.random()*names.length)];this.reaction={animation,until:now+CLAUDE_SHEETS[animation].frames*80};
    }
    const animation=this.reaction&&state!=='approval'?this.reaction.animation:activityAnimation(state);
    this.setAnimation(animation);
    const sheet=CLAUDE_SHEETS[animation],scale=2*this.read().petSize/100;
    const frame=this.reduced()?sheet.still:Math.floor((now-this.started)/80)%sheet.frames;
    const pose=spritePosition(sheet,frame,scale);
    for(const node of [this.sprite,this.ink]) {
      node.style.left=pose.left+'px';node.style.top=pose.top+'px';node.style.width=pose.width+'px';node.style.height=pose.height+'px';
    }
    this.sprite.style.backgroundImage=`url("${sheet.body}")`;this.sprite.style.backgroundSize=pose.backgroundWidth+'px '+pose.backgroundHeight+'px';this.sprite.style.backgroundPosition=pose.x+'px '+pose.y+'px';
    this.ink.style.maskImage=`url("${sheet.ink}")`;this.ink.style.maskSize=pose.backgroundWidth+'px '+pose.backgroundHeight+'px';this.ink.style.maskPosition=pose.x+'px '+pose.y+'px';
    this.hit.style.left=pose.left+'px';this.hit.style.top=pose.top+'px';this.hit.style.width=pose.width+'px';this.hit.style.height=pose.height+'px';
    this.node.setAttribute('data-gpx-pet-state',state);this.hit.setAttribute('aria-label','Clawd · '+(ACTIVITY_LABELS[state]||'空闲')+'，单击互动，双击挠痒');this.hit.title='Clawd · '+(ACTIVITY_LABELS[state]||'空闲');
    if(!this.reduced())this.timer=setTimeout(()=>this.tick(),80);
    else if(this.reaction||this.moment)this.timer=setTimeout(()=>this.tick(),Math.max(80,(this.reaction?.until??this.moment.until)-now));
    else if(state==='idle')this.timer=setTimeout(()=>this.tick(),Math.max(100,60000-(now-this.lastActivity)));
  }
  detach(){clearTimeout(this.timer);this.timer=0;this.sizeObserver?.disconnect();this.node?.remove();this.node=null;this.card=null;this.root=null;this.animation='';}
  dispose(){this.detach();document.removeEventListener('pointerdown',this.userActivity);document.removeEventListener('keydown',this.userActivity);document.removeEventListener('scroll',this.place,true);window.removeEventListener?.('resize',this.place);document.removeEventListener('visibilitychange',this.visibility);}
}

function createRunningStar(style) {
  const star=element('span','gpx-star gpx-running-star');star.setAttribute('aria-hidden','true');star.dataset.style=style;
  if(style==='claude-rhythm')star.innerHTML=CLAUDE_STAR_RHYTHM;
  return star;
}
function syncRunningStar(star,prefs) {
  const svg=star.querySelector('svg');if(!svg)return;
  const reduced=prefs.motion==='reduced'||matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(reduced||document.hidden){svg.pauseAnimations();if(reduced)svg.setCurrentTime(0);}else svg.unpauseAnimations();
}
function createSignatureStar(style) {
  if(style!=='claude-rhythm')return element('span','gpx-star');
  const star=createRunningStar(style);star.classList.remove('gpx-running-star');return star;
}
function mountClaudeFeatures(ctx,read) {
  const running=new Map(),signatures=new Map();let dead=false,pending=0,statusSource=null,statusOff=null;const statusFibers=[];
  let activeCard=null,activeSession=null;
  const pet=new ClaudeCompanion(read,()=>schedule());
  const restoredIcon=(entry)=>{entry.star.remove();if(entry.icon){if(entry.previous===null)entry.icon.removeAttribute('data-gpx-native-running-icon');else entry.icon.setAttribute('data-gpx-native-running-icon',entry.previous);}};
  function liveStatus(root) {
    let snapshot;try{snapshot=statusSource?.getSnapshot?.();}catch{return null;}
    const id=root?.querySelector('[data-conversation-session]')?.getAttribute('data-conversation-session')??root?.getAttribute('data-conversation-session');
    if(id)return snapshot?.get?.(id)??snapshot?.byId?.[id]??null;
    const values=typeof snapshot?.values==='function'?[...snapshot.values()]:Object.values(snapshot?.byId??{});
    return {running:values.some(value=>value.running===true),pendingInteraction:values.find(value=>value.pendingInteraction!==undefined)?.pendingInteraction};
  }
  function sync() {
    if(dead)return;
    const prefs=read(),wantedRunning=new Set(),wantedSignatures=new Set();
    if(prefs.enabled&&['claude','claude-rhythm'].includes(prefs.runningStyle)) for(const seat of document.querySelectorAll('[data-chat-running]:not([data-holding]):not([aria-hidden="true"])')) {
      if(!conversationRoot(seat))continue;
      wantedRunning.add(seat);
      let entry=running.get(seat);const icon=findNativeRunningIcon(seat);
      if(entry&&(entry.icon!==icon||entry.style!==prefs.runningStyle)){restoredIcon(entry);running.delete(seat);entry=null;}
      if(!entry) {
        const star=createRunningStar(prefs.runningStyle);
        entry={star,icon,style:prefs.runningStyle,previous:icon?.getAttribute('data-gpx-native-running-icon')??null};
        if(icon){icon.setAttribute('data-gpx-native-running-icon','');icon.before(star);}else seat.prepend(star);
        running.set(seat,entry);
      }else if(!entry.star.isConnected){if(icon)icon.before(entry.star);else seat.prepend(entry.star);}
    }
    for(const [seat,entry] of running)if(!wantedRunning.has(seat)){restoredIcon(entry);running.delete(seat);}
    if(prefs.enabled&&['claude','claude-rhythm'].includes(prefs.replySignatureStyle)) {
      const roots=[...document.querySelectorAll('[data-phase="active"]')].filter(root=>conversationRoot(root)===root);
      for(const root of roots) {
        const seats=[...root.querySelectorAll('[data-turn-tail][data-actions-reveal="always"]')].filter(seat=>seat.querySelector(':scope > [data-clock="end"]')!==null);
        for(const seat of prefs.signatureScope==='latest'?seats.slice(-1):seats)wantedSignatures.add(seat);
      }
    }
    for(const [seat,node] of signatures)if(!wantedSignatures.has(seat)){node.remove();signatures.delete(seat);}
    for(const seat of wantedSignatures) {
      let node=signatures.get(seat);if(!node){node=element('span','gpx-reply-signature');node.setAttribute('aria-hidden','true');signatures.set(seat,node);}
      if(node.dataset.style!==prefs.replySignatureStyle){node.dataset.style=prefs.replySignatureStyle;node.replaceChildren(createSignatureStar(prefs.replySignatureStyle));}
      if(node.parentElement!==seat)seat.append(node);
    }
    for(const star of document.querySelectorAll('.gpx-star[data-style="claude-rhythm"]'))syncRunningStar(star,prefs);
    let card=null,root=null;
    if(prefs.enabled&&prefs.petStyle==='claude')for(const candidate of document.querySelectorAll('[data-composer-card]')) {
      const parent=conversationRoot(candidate);
      if(parent&&(prefs.petScope==='all'||parent.getAttribute('data-phase')==='hero')&&candidate.getBoundingClientRect().width>0){card=candidate;root=parent;break;}
    }
    const session=card?.closest('[data-conversation-session]')?.getAttribute('data-conversation-session')??root?.getAttribute('data-conversation-session')??null;
    if(card!==activeCard||session!==activeSession){pet.detach();activeCard=card;activeSession=session;pet.attach(card,root);}
    if(card)pet.update(readDomActivity(root,liveStatus(root)));
  }
  function schedule(){if(dead||pending)return;pending=setTimeout(()=>{pending=0;sync();},40);}
  const observer=new MutationObserver(records=>{
    if(records.every(record=>{const node=record.target instanceof Element?record.target:record.target.parentElement;return node?.closest('.gpx-pet,.gpx-reply-signature,.gpx-running-star,.gpx-settings,.gpx-dialog');}))return;
    for(const record of records)if(pet.root&&record.type==='attributes'&&record.attributeName==='data-state'&&record.target.getAttribute('data-state')==='error'&&conversationRoot(record.target)===pet.root)pet.error();
    schedule();
  });
  observer.observe(document.body,{subtree:true,childList:true,attributes:true,attributeFilter:['data-state','data-cordis-status','data-streaming','data-phase','data-holding','data-actions-reveal','data-turn-tail','data-conversation-session','hidden']});
  function bindStatus(scope){scope.effect(()=>{
    let next=service(scope,'uiSession.sessionStatus');
    if(!next)try{const ui=service(scope,'uiSession');if(ui&&'sessionStatus' in ui)next=ui.sessionStatus;}catch{/* A newer host exposes this only as an injected subservice. */}
    if(!next||next===statusSource)return()=>{};
    statusOff?.();statusSource=next;statusOff=next.subscribe?.(schedule);schedule();
    return()=>{if(statusSource===next){statusOff?.();statusOff=null;statusSource=null;}};
  });}
  if(typeof ctx.inject==='function')for(const name of ['uiSession','uiSession.sessionStatus'])statusFibers.push(ctx.inject([name],bindStatus));
  sync();
  return {sync,dispose(){dead=true;clearTimeout(pending);observer.disconnect();pet.dispose();statusOff?.();statusOff=null;statusSource=null;for(const fiber of statusFibers)fiber?.dispose?.();for(const entry of running.values())restoredIcon(entry);running.clear();for(const node of signatures.values())node.remove();signatures.clear();}};
}
