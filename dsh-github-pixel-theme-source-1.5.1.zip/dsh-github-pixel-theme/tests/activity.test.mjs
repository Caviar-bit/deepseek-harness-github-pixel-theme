import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {classifyActivity,activityAnimation,spritePosition,findNativeRunningIcon} from '../src/activity.js';
import {normalize,readProfile,ID} from '../src/preferences.js';
test('approval outranks work, and idle resumes after all running signals clear',()=>{
  assert.equal(classifyActivity({approval:true,tool:true,thinking:true,streaming:true,running:true}),'approval');
  assert.equal(classifyActivity({tool:true,thinking:true,running:true}),'tool');
  assert.equal(classifyActivity({compacting:true,streaming:true,running:true}),'compacting');
  assert.equal(classifyActivity({streaming:true,running:true}),'responding');
  assert.equal(classifyActivity({running:true}),'thinking');assert.equal(classifyActivity({}),'idle');
  assert.equal(activityAnimation('responding'),'typing');assert.equal(activityAnimation('approval'),'notification');
});
test('all referenced animations have complete locally bundled artwork and valid still poses',()=>{
  const root=new URL('../src/assets/claude/',import.meta.url),sheets=JSON.parse(fs.readFileSync(new URL('sheets.json',root),'utf8'));
  for(const state of ['idle','thinking','responding','tool','approval','compacting','conducting','happy','error','sleeping'])assert.ok(sheets[activityAnimation(state)]);
  for(const [name,sheet] of Object.entries(sheets)){
    assert.ok(sheet.still>=0&&sheet.still<sheet.frames);
    for(const suffix of ['', '-ink']){
      const data=fs.readFileSync(new URL(name+suffix+'.png',root));assert.equal(data.toString('hex',0,8),'89504e470d0a1a0a');
      assert.equal(data.readUInt32BE(16),sheet.box[2]*8);assert.equal(data.readUInt32BE(20),sheet.box[3]*Math.ceil(sheet.frames/8));
    }
    for(const index of [0,7,8,sheet.frames-1]){const pose=spritePosition(sheet,index,2);assert.ok(pose.x<=0&&pose.y<=0);assert.ok(-pose.x+pose.width<=pose.backgroundWidth);assert.ok(-pose.y+pose.height<=pose.backgroundHeight);}
  }
});
test('pet and star preferences survive legacy-compatible exports and invalid options are clamped',()=>{
  const prefs=normalize({petStyle:'none',petSize:1000,runningStyle:'native',replySignatureStyle:'none',signatureScope:'all',starColor:'#be7355'});
  assert.equal(prefs.petSize,150);assert.equal(prefs.petStyle,'none');assert.equal(prefs.runningStyle,'native');
  assert.deepEqual(readProfile(JSON.stringify({theme:ID,version:1,preferences:prefs})),prefs);
  assert.equal(normalize({petStyle:'other',petSize:NaN}).petStyle,'claude');
  assert.equal(normalize({}).replySignatureStyle,'claude');
});
test('replaces both native whale layers without hiding status text or clipping the star',()=>{
  const wrapper={getAttribute:name=>name==='aria-hidden'?'true':null,querySelector:()=>null};
  const svg={parentElement:wrapper};
  const seat={querySelector:selector=>selector==='svg'?svg:null};
  assert.equal(findNativeRunningIcon(seat),wrapper,'replace the whole animated/still icon container');
  const content={getAttribute:()=>null,querySelector:()=>({text:'运行中 · 6秒'})};
  svg.parentElement=content;
  assert.equal(findNativeRunningIcon(seat),svg,'leave a shared text container visible for older single-SVG renderers');
  svg.parentElement=wrapper;
  const animationOnly={querySelector:selector=>selector==='svg'?null:{parentElement:wrapper}};
  assert.equal(findNativeRunningIcon(animationOnly),wrapper,'animated-mask-only renderers are handled too');
});
test('rhythm selection round-trips without changing breathing defaults or reply signatures',()=>{
 const p=normalize({runningStyle:'claude-rhythm',starColor:'#123456'});assert.equal(p.runningStyle,'claude-rhythm');
 assert.deepEqual(readProfile(JSON.stringify({theme:ID,version:1,preferences:p})),p);
 assert.equal(normalize({}).runningStyle,'claude');assert.equal(p.replySignatureStyle,'claude');
});
test('adapted rhythm SVG preserves the complete seamless morph with a bounded 20 px viewport',()=>{
 const s=fs.readFileSync(new URL('../src/assets/claude/star-rhythm.svg',import.meta.url),'utf8');
 assert.match(s,/width="20" height="20"/);assert.match(s,/fill="currentColor"/);assert.match(s,/dur="0.874s"/);
 const frames=s.match(/values="([^"]+)"/)[1].split(';');assert.equal(frames.length,49);assert.equal(frames[0],frames.at(-1));
 const box=s.match(/viewBox="([^"]+)"/)[1].split(' ').map(Number);assert.equal(box[2],box[3]);
 const commands=frames[0].replace(/[^MLQZ]/g,'');for(const d of frames){assert.equal(d.replace(/[^MLQZ]/g,''),commands);const n=d.match(/-?\d+(?:\.\d+)?/g).map(Number);for(let i=0;i<n.length;i+=2){assert.ok(n[i]>=box[0]&&n[i]<=box[0]+box[2]);assert.ok(n[i+1]>=box[1]&&n[i+1]<=box[1]+box[3]);}}
 assert.doesNotMatch(s,/<script|onload|href=|<foreignObject/i);
});
test('native icon detection ignores the inline rhythm replacement during repeated sync',()=>{
 const wrapper={getAttribute:()=> 'true',querySelector:()=>null},native={parentElement:wrapper,closest:()=>null},own={closest:()=>({})};
 assert.equal(findNativeRunningIcon({querySelectorAll:()=>[own,native]}),wrapper);
});
test('reply rhythm is independent of output style and survives profile export',()=>{
 for(const runningStyle of ['claude','claude-rhythm','native']){const p=normalize({replySignatureStyle:'claude-rhythm',runningStyle,signatureScope:'all'});assert.equal(p.replySignatureStyle,'claude-rhythm');assert.equal(p.runningStyle,runningStyle);assert.equal(readProfile(JSON.stringify({theme:ID,version:1,preferences:p})).replySignatureStyle,'claude-rhythm');}
 assert.equal(normalize({replySignatureStyle:'invalid'}).replySignatureStyle,'claude');
});
