import {test} from 'node:test';
import assert from 'node:assert/strict';
import {stepAntigravity,particleFrameDue,nextParticleFrame} from '../src/antigravity.js';
import {normalize,readProfile,ID} from '../src/preferences.js';
test('frame deadlines preserve 45 and 60 fps on a 60 Hz display without half-rate quantization',()=>{
 for(const target of [45,60]){let deadline=0,frames=0;for(let i=0;i<600;i++){const now=i*1000/60;if(particleFrameDue(deadline,now)){frames++;deadline=nextParticleFrame(deadline,now,1000/target);}}assert.ok(Math.abs(frames-target*10)<=1);}
 assert.equal(nextParticleFrame(20,5000,1000/60),5000+1000/60);
});
test('old profiles retain GitHub and new effect parameters round trip',()=>{
 assert.equal(normalize({}).backgroundEffect,'github');
 const prefs=normalize({backgroundEffect:'antigravity',particleCount:1e6,particleForce:-1});
 assert.equal(prefs.particleCount,16000);assert.equal(prefs.particleForce,20);
 assert.deepEqual(readProfile(JSON.stringify({theme:ID,version:1,preferences:prefs})),prefs);
 assert.equal(normalize({...prefs,particleOpacity:35,intensity:85}).particleOpacity,35);
 assert.equal(normalize({...prefs,particleOpacity:35,intensity:85}).intensity,85);
});
test('legacy particle defaults upgrade without changing GitHub settings or custom counts',()=>{
 const prefs=normalize({backgroundEffect:'antigravity',particleCount:2400,fps:45,intensity:73});
 assert.equal(prefs.particleCount,9000);assert.equal(prefs.particleFps,60);assert.equal(prefs.fps,45);assert.equal(prefs.intensity,73);
 assert.equal(normalize({particleCount:3600}).particleCount,3600);
});
test('a stationary pointer still has continuous visible wave motion',()=>{
 const p={homeX:180,homeY:100,x:180,y:100,vx:0,vy:0,seed:.3};
 const pos=[];for(let i=0;i<360;i++){stepAntigravity(p,{x:100,y:100,active:true},1/60,i/60,{radius:80,force:1,speed:1});if(i>120)pos.push(p.x);}
 assert.ok(Math.max(...pos)-Math.min(...pos)>8,'waves must keep moving after pointer stops');
});
test('a pointer displaces existing particles and released particles return with inertia',()=>{
 const particle={homeX:180,homeY:100,x:180,y:100,vx:0,vy:0,seed:.3};
 const settings={radius:80,force:1,speed:0};
 for(let i=0;i<120;i++)stepAntigravity(particle,{x:100,y:100,active:true},1/60,i/60,settings);
 assert.ok(Math.hypot(particle.x-180,particle.y-100)>8);
 const before=particle.x;stepAntigravity(particle,{x:2000,y:2000,active:false},1/60,2,settings);
 assert.notEqual(particle.x,180);assert.notEqual(particle.x,before);
 for(let i=0;i<480;i++)stepAntigravity(particle,{x:2000,y:2000,active:false},1/60,2+i/60,settings);
 assert.ok(Math.hypot(particle.x-180,particle.y-100)<.01);
 assert.ok(Number.isFinite(stepAntigravity(particle,{x:180,y:100,active:true},10,10,settings).x));
});
