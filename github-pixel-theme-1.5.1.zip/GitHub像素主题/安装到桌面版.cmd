@echo off
setlocal
chcp 65001 >nul
title GitHub Pixel Theme Installer
set "GPX_THEME_PACKAGE=%~dp0dsh-github-pixel-theme-1.5.1.tgz"
if not exist "%GPX_THEME_PACKAGE%" (
  echo 找不到主题安装包，请完整解压 ZIP 后重试。
  pause
  exit /b 1
)
where dsh >nul 2>&1
if errorlevel 1 (
  echo 未找到 dsh 命令，请打开 Harness CLI 终端，或将其 CLI 加入 PATH。
  echo 在安装包目录运行：dsh plugin --profile desktop add "./dsh-github-pixel-theme-1.5.1.tgz"
  pause
  exit /b 1
)
call dsh plugin --profile desktop add "%GPX_THEME_PACKAGE%"
if errorlevel 1 (
  echo 安装未完成，请检查上方错误信息。
  pause
  exit /b 1
)
echo 安装完成，请重启 Harness；右下角四色按钮可打开主题设置。
pause
exit /b 0
