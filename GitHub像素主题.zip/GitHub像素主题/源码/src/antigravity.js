// Independently implemented particle dynamics, inspired by antigravity.google.
export function particleFrameDue(deadline,now){return !deadline||now+.8>=deadline;}
export function nextParticleFrame(deadline,now,interval){return deadline&&now-deadline<interval*2?deadline+interval:now+interval;}
export function stepAntigravity(p, pointer, dt, time, settings) {
  const h=Math.min(.04,Math.max(0,dt)),radius=settings.radius;
  const dx=p.homeX-pointer.x,dy=p.homeY-pointer.y,d=Math.hypot(dx,dy),inv=1/Math.max(d,1);
  const angle=Math.atan2(dy,dx),flow=time*settings.speed;
  const waveRadius=radius*(1+.075*Math.sin(flow*1.7+angle*3)+.045*Math.sin(angle*5-flow*1.1));
  const band=Math.exp(-Math.pow((d-waveRadius)/Math.max(22,radius*.34),2));
  const core=Math.max(0,1-d/radius);
  const speed=settings.speed;
  const driftX=Math.sin(flow*.8+p.homeY*.009)*9*speed+Math.cos(flow*.51+p.seed*12)*4*speed;
  const driftY=Math.cos(flow*.7+p.homeX*.009)*9*speed+Math.sin(flow*.43+p.seed*11)*4*speed;
  const force=settings.force*(pointer.active?1:.36);
  const ripple=Math.sin(d/Math.max(radius,1)*9-flow*2.2+angle*.5);
  const radial=(band*(12+ripple*9)+core*ripple*6)*force,twist=(band*9+core*5)*Math.sin(flow*.7+angle)*force;
  const targetX=p.homeX+driftX+dx*inv*radial-dy*inv*twist;
  const targetY=p.homeY+driftY+dy*inv*radial+dx*inv*twist;
  const spring=38,damping=Math.exp(-9*h);
  p.vx=(p.vx+(targetX-p.x)*spring*h)*damping;p.vy=(p.vy+(targetY-p.y)*spring*h)*damping;
  p.x+=p.vx*h;p.y+=p.vy*h;p.energy=Math.min(1,band*.85+core*.5);
  return p;
}

class AntigravityField {
  constructor(root,read,onDark,preview=false) {
    this.kind='antigravity';this.root=root;this.read=read;this.onDark=onDark;this.preview=preview;
    this.dead=false;this.frame=0;this.last=0;this.clock=0;this.visible=true;this.points=[];this.signature='';
    this.pointer={x:0,y:0,targetX:0,targetY:0,active:false};
    this.choreography=new ParticleChoreography();this.center={x:0,y:0};this.orbRadius=90;
    this.canvas=element('canvas','gpx-canvas');this.canvas.dataset.gpxEffect='antigravity';this.canvas.setAttribute('aria-hidden','true');
    this.priorSurface=root.getAttribute('data-gpx-surface');root.setAttribute('data-gpx-surface','');root.append(this.canvas);
    this.renderer=new ParticleRenderer(this.canvas);this.context=this.renderer;
    this.canvas.addEventListener('webglcontextlost',this.lost=e=>{e.preventDefault();this.context=null;cancelAnimationFrame(this.frame);this.frame=0;});
    // Context loss already releases old GL objects; deleting their stale handles
    // after restoration would itself cause INVALID_OPERATION on some drivers.
    this.canvas.addEventListener('webglcontextrestored',this.restored=()=>{this.renderer=new ParticleRenderer(this.canvas);this.context=this.renderer;this.last=0;this.nextFrame=0;this.sampleStart=0;this.sampleFrames=0;this.sampleCost=0;this.wake();});
    this.move=e=>{
      const card=this.composerAt(e.target);
      if(card){this.engageComposer(card,true);if(this.choreography.suppressed){const box=root.getBoundingClientRect();this.pointer.targetX=e.clientX-box.left;this.pointer.targetY=e.clientY-box.top;this.pointer.active=true;}this.wake();return;}
      this.choreography.engage(false,this.hasComposerFocus());
      if(!this.preview&&e.target instanceof Element&&e.target.closest('button,a,input,textarea,select,[contenteditable],[data-composer-card],[role="menu"],[role="dialog"]')){this.leave();return;}
      const box=root.getBoundingClientRect();this.pointer.targetX=e.clientX-box.left;this.pointer.targetY=e.clientY-box.top;this.pointer.active=true;this.wake();
    };
    this.leave=()=>{this.pointer.active=false;this.choreography.engage(false,this.hasComposerFocus());this.wake();};
    root.addEventListener('pointermove',this.move,{passive:true});root.addEventListener('pointerleave',this.leave,{passive:true});
    this.focusIn=e=>{const card=this.composerAt(e.target);if(card)this.engageComposer(card,this.choreography.hover);};
    this.focusOut=()=>queueMicrotask(()=>{if(!this.dead){this.choreography.engage(this.choreography.hover,this.hasComposerFocus());this.wake();}});
    this.input=e=>{const card=this.composerAt(e.target);if(card){this.engageComposer(card,this.choreography.hover);this.choreography.input(!!this.editorText(card));if(this.choreography.age<0)this.positionOrb();}};
    this.click=e=>{const card=this.composerAt(e.target),button=e.target instanceof Element?e.target.closest('button,[role="button"]'):null;if(card&&isParticleSendControl(button))this.burst(card);};
    // Enter is only a candidate. A cleared editor confirms that the host accepted
    // it; IME confirmation, autocomplete and Shift+Enter cannot create a blast.
    this.key=e=>{const card=this.composerAt(e.target);if(card&&e.key==='Enter'&&!e.shiftKey&&!e.isComposing&&e.keyCode!==229&&!e.repeat&&this.editorText(card)){this.pendingKey={card,deadline:performance.now()+1600};queueMicrotask(()=>this.checkKeyboardSend());}};
    this.editorObserver=new MutationObserver(()=>this.checkKeyboardSend());this.editorObserver.observe(root,{childList:true,characterData:true,subtree:true});
    this.composerEvents=[['focusin',this.focusIn],['focusout',this.focusOut],['input',this.input],['click',this.click],['keydown',this.key]];
    if(!preview)for(const [type,handler] of this.composerEvents)document.addEventListener(type,handler,true);
    this.resizeObserver=new ResizeObserver(()=>this.resize());this.resizeObserver.observe(root);
    this.intersection=new IntersectionObserver(entries=>{this.visible=entries[0]?.isIntersecting??false;if(!this.visible){cancelAnimationFrame(this.frame);this.frame=0;this.last=0;}else this.wake();});this.intersection.observe(root);
    this.visibility=()=>{cancelAnimationFrame(this.frame);this.frame=0;this.last=0;if(!document.hidden)this.wake();};document.addEventListener('visibilitychange',this.visibility);
    this.resize();
  }
  reduced(){return this.read().motion==='reduced'||matchMedia('(prefers-reduced-motion: reduce)').matches;}
  composerAt(target){if(this.preview||!(target instanceof Element))return null;const card=target.closest('[data-composer-card]');return card&&this.root.contains(card)&&!card.closest('[role="dialog"],[role="menu"]')?card:null;}
  hasComposerFocus(){return !!this.composerAt(document.activeElement);}
  editorText(card){const input=card.querySelector('[data-composer-input],textarea,[contenteditable="true"]');return (input?.value??input?.textContent??'').trim();}
  engageComposer(card,hover){
    const changed=this.composer!==card||this.choreography.hover!==hover;this.composer=card;
    this.choreography.engage(hover,this.hasComposerFocus());if(changed&&this.choreography.age<0)this.positionOrb();this.pointer.active=false;this.wake();
  }
  positionOrb(){
    if(!this.composer?.isConnected)return;
    const root=this.root.getBoundingClientRect(),card=this.composer.getBoundingClientRect();
    const radius=Math.min(112,Math.max(48,root.width*.11),Math.max(38,(card.top-root.top-24)/2));
    this.orbRadius=radius;this.center={x:Math.max(radius+8,Math.min(root.width-radius-8,card.left-root.left+card.width*.5)),y:Math.max(radius+8,Math.min(radius+28,card.top-root.top-radius-20))};
  }
  checkKeyboardSend(){const pending=this.pendingKey;if(!pending||this.dead)return;if(performance.now()>pending.deadline){this.pendingKey=null;return;}if(pending.card.isConnected&&!this.editorText(pending.card)){this.pendingKey=null;this.burst(pending.card);}}
  burst(card){
    if(this.dead||!this.read().particleOrb||this.reduced())return;
    if(this.composer!==card){this.composer=card;this.positionOrb();}
    if(this.choreography.send(this.clock)){this.pendingKey=null;this.canvas.dataset.particleStage='burst';this.wake();}
  }
  isBursting(){return this.choreography.age>=0;}
  resize(){
    const box=this.root.getBoundingClientRect();this.width=Math.max(1,Math.ceil(box.width));this.height=Math.max(1,Math.ceil(box.height));
    this.dpr=Math.max(.5,Math.min(devicePixelRatio||1,1.75,4096/Math.max(this.width,this.height)));
    this.canvas.width=Math.round(this.width*this.dpr);this.canvas.height=Math.round(this.height*this.dpr);
    this.signature='';this.pointer.x=this.pointer.targetX=this.width*.5;this.pointer.y=this.pointer.targetY=this.height*.48;this.positionOrb();this.update();
  }
  update(){
    // Cache only when appearance/settings change, avoiding computed-style reads
    // in the render loop. Preview fields inherit the same main-surface token.
    const bg=getComputedStyle(this.root).getPropertyValue('--gpx-bg').trim()||'#ffffff';
    this.background=[1,3,5].map(i=>parseInt(bg.slice(i,i+2),16));this.surfaceDark=surfaceTone(bg).dark;
    const p=this.read(),signature=[this.width,this.height,p.particleCount].join(':');
    if(this.signature!==signature){
      this.signature=signature;this.points=[];
      const count=Math.min(p.particleCount,this.renderer.gl?16000:4500,Math.max(180,Math.round(this.width*this.height/110))),aspect=this.width/this.height;
      const cols=Math.max(1,Math.ceil(Math.sqrt(count*aspect))),rows=Math.ceil(count/cols);
      let seed=7381;const rand=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
      for(let y=0;y<rows;y++)for(let x=0;x<cols&&this.points.length<count;x++){
        const homeX=(x+.12+rand()*.76)*this.width/cols,homeY=(y+.12+rand()*.76)*this.height/rows;
        this.points.push({homeX,homeY,x:homeX,y:homeY,vx:0,vy:0,seed:rand(),energy:0});
      }
      this.data=new Float32Array(this.points.length*7);
      this.points.forEach((point,i)=>{point.orbY=1-2*(i+.5)/this.points.length;point.orbPhi=i*2.39996323;const zone=Math.sin(point.homeX/this.width*5+point.homeY/this.height*3+point.seed*.8);point.color=zone>.55?0:zone>-.2?1:zone>-.7?2:3;});
      if(this.renderer.gl){let j=0;for(const point of this.points){this.data[j++]=point.homeX;this.data[j++]=point.homeY;this.data[j++]=point.seed;this.data[j++]=point.orbY;this.data[j++]=point.orbPhi;this.data[j++]=point.color;this.data[j++]=0;}}
      this.canvas.dataset.particleCount=String(this.points.length);
    }
    this.wake();
  }
  wake(){if(this.dead||this.frame||document.hidden||!this.visible)return;this.frame=requestAnimationFrame(now=>this.paint(now));}
  paint(now){
    this.frame=0;if(this.dead||document.hidden||!this.visible||!this.context){this.last=0;return;}
    const prefs=this.read(),reduced=this.reduced(),interval=1000/prefs.particleFps;
    if(!particleFrameDue(this.nextFrame,now)){if(!reduced)this.wake();return;}
    this.nextFrame=nextParticleFrame(this.nextFrame,now,interval);
    const dt=this.last?Math.min(.04,(now-this.last)/1000):1/60;this.last=now;if(!reduced)this.clock+=dt;
    const t=this.clock,p=this.pointer;
    const wasBursting=this.choreography.age>=0;
    const mode=this.choreography.advance(dt,prefs.particleOrb&&!reduced),stage=this.choreography.uniforms(t);
    if(wasBursting&&mode!=='burst')this.root.dispatchEvent(new Event('gpx-burst-end',{bubbles:true}));
    if(this.canvas.dataset.particleStage!==mode)this.canvas.dataset.particleStage=mode;
    const flowTime=t*prefs.particleSpeed/50;
    if(!p.active){p.targetX=this.width*(.5+Math.sin(flowTime*.14)*.13);p.targetY=this.height*(.48+Math.cos(flowTime*.17)*.08);}
    const follow=1-Math.exp(-dt*9);p.x+=(p.targetX-p.x)*follow;p.y+=(p.targetY-p.y)*follow;
    const radius=Math.min(prefs.particleRadius,Math.min(this.width,this.height)*.38);
    const settings={radius,force:prefs.particleForce/100,speed:prefs.particleSpeed/50};
    const started=performance.now(),dark=this.surfaceDark;let index=0;
    if(!this.renderer.gl)for(const point of this.points){
      if(!reduced)stepAntigravity(point,p,dt,t,settings);
      const projected=projectParticleStage(point,t,this.center,this.orbRadius,stage,this.width,this.height),weight=projected.amount;
      const energy=reduced?0:point.energy;
      const angle=point.seed*6.283+energy*.9+Math.sin(t*.8+point.seed*9)*energy*.45;
      const size=prefs.particleSize*(.45+point.seed*.45+energy*.9),length=size*(.5+energy*1.1)*(1-weight);
      this.data[index++]=projected.x;this.data[index++]=projected.y;this.data[index++]=length;this.data[index++]=Math.max(.7,size*.68);this.data[index++]=angle;this.data[index++]=weight>.2?Math.floor(((projected.phi/6.283%1)+1)%1*4):point.color;this.data[index++]=Math.max(Math.min(.92,(dark?.4:.3)+energy*.6)*(1-weight)+(.18+projected.depth*.72)*weight,projected.burst*.65)*prefs.particleOpacity/100;
    }
    this.interactionWeight=(this.interactionWeight??.36)+((p.active?1:.36)-(this.interactionWeight??.36))*follow;
    this.renderer.draw(this.data,this.points.length,this.width,this.height,this.dpr,dark,{stage,center:this.center,orbRadius:this.orbRadius,background:this.background,x:p.x,y:p.y,time:t,radius,speed:settings.speed,force:settings.force*this.interactionWeight,size:prefs.particleSize,opacity:prefs.particleOpacity/100,motion:reduced?0:1});
    this.sampleFrames=(this.sampleFrames||0)+1;this.sampleCost=(this.sampleCost||0)+performance.now()-started;
    if(!this.sampleStart)this.sampleStart=now;
    if(now-this.sampleStart>=750){this.canvas.dataset.measuredFps=(this.sampleFrames*1000/(now-this.sampleStart)).toFixed(1);this.canvas.dataset.renderMs=(this.sampleCost/this.sampleFrames).toFixed(2);this.sampleStart=now;this.sampleFrames=0;this.sampleCost=0;}
    if(!reduced)this.wake();
  }
  dispose(){this.dead=true;cancelAnimationFrame(this.frame);this.frame=0;this.editorObserver.disconnect();for(const [type,handler] of this.composerEvents)document.removeEventListener(type,handler,true);this.pendingKey=null;this.resizeObserver.disconnect();this.intersection.disconnect();document.removeEventListener('visibilitychange',this.visibility);this.root.removeEventListener('pointermove',this.move);this.root.removeEventListener('pointerleave',this.leave);this.canvas.removeEventListener('webglcontextlost',this.lost);this.canvas.removeEventListener('webglcontextrestored',this.restored);this.renderer.dispose();this.canvas.remove();this.points=[];if(this.priorSurface===null)this.root.removeAttribute('data-gpx-surface');else this.root.setAttribute('data-gpx-surface',this.priorSurface);}
}

function createBackgroundField(root,read,dark,preview=false){return read().backgroundEffect==='antigravity'?new AntigravityField(root,read,dark,preview):new PixelField(root,read,dark,preview);}
