// Shared state and projection for the GPU path and the Canvas fallback.
export const PARTICLE_BURST_DURATION=2.8;
const smoothParticle=(a,b,x)=>{const t=Math.max(0,Math.min(1,(x-a)/(b-a)));return t*t*(3-2*t);};
export class ParticleChoreography {
  constructor(){this.amount=0;this.age=-1;this.hover=false;this.focus=false;this.suppressed=false;this.startAmount=0;this.orbTime=0;}
  engage(hover,focus){
    if(!this.hover&&hover&&this.age<0)this.suppressed=false;
    this.hover=hover;this.focus=focus;
  }
  input(nonempty){if(nonempty)this.suppressed=false;}
  send(time){
    if(this.age>=0)return false;
    this.startAmount=this.amount;this.orbTime=time;this.age=0;this.suppressed=true;return true;
  }
  advance(dt,enabled=true){
    if(!enabled){this.amount=0;this.age=-1;return 'field';}
    if(this.age>=0){this.age+=Math.max(0,dt);if(this.age<PARTICLE_BURST_DURATION)return 'burst';this.age=-1;this.amount=0;}
    const target=!this.suppressed&&(this.hover||this.focus)?1:0;
    const step=Math.max(0,dt)/.95;
    this.amount=Math.max(0,Math.min(1,this.amount+Math.sign(target-this.amount)*Math.min(step,Math.abs(target-this.amount))));
    return this.amount>.999?'orb':this.amount>0?'gather':'field';
  }
  uniforms(time){return {amount:smoothParticle(0,1,this.amount),age:this.age,startAmount:smoothParticle(0,1,this.startAmount),orbTime:this.age>=0?this.orbTime:time};}
}
export function projectParticleOrb(point,time,radius){
  const y=point.orbY,ring=Math.sqrt(Math.max(0,1-y*y));
  const phi=point.orbPhi+time*.55+Math.sin(y*3+time*.7)*.55;
  const warp=1+.13*Math.sin(phi*3+y*4-time*1.2)+.09*Math.sin(y*6+time*1.4);
  const x=Math.cos(phi)*ring*warp,z=Math.sin(phi)*ring*warp;
  const tilt=.35+.2*Math.sin(time*.32),yy=y*Math.cos(tilt)-z*Math.sin(tilt),zz=y*Math.sin(tilt)+z*Math.cos(tilt);
  const perspective=3/(3-zz*.65);
  return {x:x*radius*perspective,y:yy*radius*perspective,depth:Math.max(0,Math.min(1,zz*.5+.5)),phi};
}
export function projectParticleStage(point,time,center,radius,stage,width,height){
  if(stage.amount===0&&stage.age<0)return {x:point.x,y:point.y,depth:0,phi:0,amount:0,burst:0};
  const orb=projectParticleOrb(point,stage.orbTime,radius);
  let amount=stage.amount,x=point.x+(center.x+orb.x-point.x)*amount,y=point.y+(center.y+orb.y-point.y)*amount,burst=0;
  if(stage.age>=0){
    burst=1-smoothParticle(1.05,PARTICLE_BURST_DURATION,stage.age);amount=stage.startAmount*burst;
    const length=Math.max(1,Math.hypot(orb.x,orb.y)),travel=(1-Math.exp(-stage.age*2.4))*Math.hypot(width,height)*(.22+point.seed*.56);
    const spin=Math.sin(stage.age*2+point.seed*6)*stage.age*18;
    x=point.x+((center.x+orb.x-point.x)*stage.startAmount+orb.x/length*travel-orb.y/length*spin)*burst;
    y=point.y+((center.y+orb.y-point.y)*stage.startAmount+orb.y/length*travel+orb.x/length*spin+stage.age*stage.age*24)*burst;
  }
  return {x,y,depth:orb.depth,phi:orb.phi,amount,burst};
}
export function isParticleSendControl(button){
  if(!button||button.disabled||button.getAttribute('aria-disabled')==='true'||button.hasAttribute('data-sending')||button.getAttribute('aria-busy')==='true')return false;
  const label=button.getAttribute('aria-label')||button.getAttribute('title')||'';
  return button.hasAttribute('data-gpx-send')||/发送|\bsend\b/i.test(label);
}
