import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {classifyActivity,activityAnimation,spritePosition,findNativeRunningIcon} from '../src/activity.js';
import {normalize,readProfile,ID} from '../src/preferences.js';
test('approval outranks work, and idle resumes after all running signals clear',()=>{
  assert.equal(classifyActivity({approval:true,tool:true,thinking:true,streaming:true,running:true}),'approval');
  assert.equal(classifyActivity({tool:true,thinking:true,running:true}),'tool');
  assert.equal(classifyActivity({compacting:true,streaming:true,running:true}),'compacting');
  assert.equal(classifyActivity({streaming:true,running:true}),'responding');
  assert.equal(classifyActivity({running:true}),'thinking');assert.equal(classifyActivity({}),'idle');
  assert.equal(activityAnimation('responding'),'typing');assert.equal(activityAnimation('approval'),'notification');
});
test('all referenced animations have complete locally bundled artwork and valid still poses',()=>{
  const root=new URL('../src/assets/claude/',import.meta.url),sheets=JSON.parse(fs.readFileSync(new URL('sheets.json',root),'utf8'));
  for(const state of ['idle','thinking','responding','tool','approval','compacting','conducting','happy','error','sleeping'])assert.ok(sheets[activityAnimation(state)]);
  for(const [name,sheet] of Object.entries(sheets)){
    assert.ok(sheet.still>=0&&sheet.still<sheet.frames);
    for(const suffix of ['', '-ink']){
      const data=fs.readFileSync(new URL(name+suffix+'.png',root));assert.equal(data.toString('hex',0,8),'89504e470d0a1a0a');
      assert.equal(data.readUInt32BE(16),sheet.box[2]*8);assert.equal(data.readUInt32BE(20),sheet.box[3]*Math.ceil(sheet.frames/8));
    }
    for(const index of [0,7,8,sheet.frames-1]){const pose=spritePosition(sheet,index,2);assert.ok(pose.x<=0&&pose.y<=0);assert.ok(-pose.x+pose.width<=pose.backgroundWidth);assert.ok(-pose.y+pose.height<=pose.backgroundHeight);}
  }
});
test('pet and star preferences survive legacy-compatible exports and invalid options are clamped',()=>{
  const prefs=normalize({petStyle:'none',petSize:1000,runningStyle:'native',replySignatureStyle:'none',signatureScope:'all',starColor:'#be7355'});
  assert.equal(prefs.petSize,150);assert.equal(prefs.petStyle,'none');assert.equal(prefs.runningStyle,'native');
  assert.deepEqual(readProfile(JSON.stringify({theme:ID,version:1,preferences:prefs})),prefs);
  assert.equal(normalize({petStyle:'other',petSize:NaN}).petStyle,'claude');
  assert.equal(normalize({}).replySignatureStyle,'claude');
});
test('replaces both native whale layers without hiding status text or clipping the star',()=>{
  const wrapper={getAttribute:name=>name==='aria-hidden'?'true':null,querySelector:()=>null};
  const svg={parentElement:wrapper};
  const seat={querySelector:selector=>selector==='svg'?svg:null};
  assert.equal(findNativeRunningIcon(seat),wrapper,'replace the whole animated/still icon container');
  const content={getAttribute:()=>null,querySelector:()=>({text:'运行中 · 6秒'})};
  svg.parentElement=content;
  assert.equal(findNativeRunningIcon(seat),svg,'leave a shared text container visible for older single-SVG renderers');
  svg.parentElement=wrapper;
  const animationOnly={querySelector:selector=>selector==='svg'?null:{parentElement:wrapper}};
  assert.equal(findNativeRunningIcon(animationOnly),wrapper,'animated-mask-only renderers are handled too');
});
