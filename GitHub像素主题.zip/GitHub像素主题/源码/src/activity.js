export const ACTIVITY_LABELS={idle:'空闲',thinking:'思考中',responding:'正在输出',tool:'正在使用工具',approval:'等待确认',compacting:'整理上下文',conducting:'协调子代理',happy:'已完成',error:'遇到错误',sleeping:'休息中'};
export function classifyActivity({approval=false,compacting=false,conducting=false,tool=false,thinking=false,streaming=false,running=false}={}) {
  if(approval)return 'approval';if(compacting)return 'compacting';if(conducting)return 'conducting';
  if(tool)return 'tool';if(thinking)return 'thinking';if(streaming)return 'responding';return running?'thinking':'idle';
}
export function activityAnimation(state) {
  return {idle:'idle',thinking:'thinking',responding:'typing',tool:'building',approval:'notification',compacting:'compacting',conducting:'conducting',happy:'happy',error:'error',sleeping:'sleeping'}[state]??'idle';
}
export function spritePosition(sheet,frame,scale) {
  const index=Math.max(0,Math.min(sheet.frames-1,Math.floor(frame)));
  const [x,y,width,height]=sheet.box;
  return {left:x*scale,top:y*scale,width:width*scale,height:height*scale,
    backgroundWidth:width*8*scale,backgroundHeight:height*Math.ceil(sheet.frames/8)*scale,
    x:-(index%8)*width*scale,y:-Math.floor(index/8)*height*scale};
}
export function findNativeRunningIcon(seat) {
  const svg=seat.querySelector('svg');
  if(svg) {
    const wrapper=svg.parentElement;
    // RunningWhaleTail owns both an animated mask span and a still SVG.
    // Replace their aria-hidden wrapper so the animation cannot remain behind.
    if(wrapper&&wrapper!==seat&&wrapper.getAttribute('aria-hidden')==='true'&&!wrapper.querySelector('[data-shimmer],[role="status"]'))return wrapper;
    return svg;
  }
  const animated=seat.querySelector('[class*="_runningWhaleAnimated"]');
  const wrapper=animated?.parentElement;
  return wrapper&&wrapper!==seat&&wrapper.getAttribute('aria-hidden')==='true'?wrapper:null;
}
