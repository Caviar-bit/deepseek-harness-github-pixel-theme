// One GPU draw call per field. A batched 2D fallback supports hosts without WebGL2.
class ParticleRenderer {
 constructor(canvas){
  // This field owns a flat theme surface. Paint that surface explicitly rather
  // than relying on transparent accelerated layers in the Electron compositor.
  this.canvas=canvas;this.gl=canvas.getContext('webgl2',{alpha:false,antialias:false,depth:false,stencil:false,powerPreference:'high-performance'});
  if(!this.gl){this.ctx=canvas.getContext('2d',{alpha:false});canvas.dataset.renderer='canvas2d';return;}
  const gl=this.gl;
  const shader=(type,source)=>{const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;};
  const vs=shader(gl.VERTEX_SHADER,`#version 300 es
  precision highp float;in vec2 aPosition;in vec3 aShape;in vec2 aStyle;uniform vec2 uSize;uniform float uDpr;
  uniform vec2 uPointer;uniform vec4 uFlow;uniform vec3 uLook;
  uniform vec4 uStage;uniform vec3 uOrb;uniform vec3 uColors[4];uniform vec3 uSphereColors[4];
  out vec3 vShape;out vec3 vTint;out float vOpacity;out float vDiameter;
  void main(){float seed=aShape.x,time=uFlow.x*uFlow.z,r=uFlow.y;vec2 delta=aPosition-uPointer;float d=length(delta),angle=atan(delta.y,delta.x);
  float waveR=r*(1.+.075*sin(time*1.7+angle*3.)+.045*sin(angle*5.-time*1.1));float band=exp(-pow((d-waveR)/max(22.,r*.34),2.));
  float core=max(0.,1.-d/r);float ripple=sin(d/r*9.-time*2.2+angle*.5);float radial=(band*(12.+ripple*9.)+core*ripple*6.)*uFlow.w;
  float twist=(band*9.+core*5.)*sin(time*.7+angle)*uFlow.w;vec2 dir=delta/max(d,1.);
  vec2 drift=vec2(sin(time*.8+aPosition.y*.009)*9.+cos(time*.51+seed*12.)*4.,cos(time*.7+aPosition.x*.009)*9.+sin(time*.43+seed*11.)*4.)*uFlow.z;
  float motion=uLook.z;vec2 position=aPosition+(drift+dir*radial+vec2(-dir.y,dir.x)*twist)*motion;
  float energy=min(1.,band*.85+core*.5)*motion;
  float orbY=aShape.y,orbRing=sqrt(max(0.,1.-orbY*orbY)),ot=uStage.w;
  float group=floor(seed*7.),volume=.12+.88*pow(seed,.42);
  float phi=aShape.z+ot*(.12+seed*.18)+sin(orbY*3.+ot*.45+seed*6.)*.35;
  float warp=1.+.20*sin(phi*2.3+orbY*4.-ot*.45)+.12*cos(phi*3.7-orbY*2.+ot*.7);
  float ox=cos(phi)*orbRing*volume*warp*(1.+.10*sin(ot*.4))+.30*sin(group*2.4+ot*.27)+.06*sin(seed*79.+ot*.83);
  float vy=orbY*volume*warp*.85+.22*cos(group*1.7-ot*.23)+.05*sin(seed*53.-ot*.7);
  float oz=sin(phi)*orbRing*volume*warp+.25*sin(group*3.1+ot*.21),tilt=.35+.2*sin(ot*.32);
  float oy=vy*cos(tilt)-oz*sin(tilt),depthZ=vy*sin(tilt)+oz*cos(tilt),depth=clamp(depthZ*.5+.5,0.,1.);
  vec2 orb=vec2(ox,oy)*uOrb.z*3./(3.-depthZ*.65),base=position;
  float amount=smoothstep(seed*.16,1.-seed*.12,uStage.x),burst=0.;position=mix(base,uOrb.xy+orb,amount);
  if(uStage.y>=0.){float age=uStage.y,startAmount=smoothstep(seed*.16,1.-seed*.12,uStage.z);burst=1.-smoothstep(1.05,2.8,age);amount=startAmount*burst;
   vec2 direction=orb/max(length(orb),1.);float travel=(1.-exp(-age*2.4))*length(uSize)*(.22+seed*.56),spin=sin(age*2.+seed*6.)*age*18.;
   position=base+((uOrb.xy+orb-base)*startAmount+direction*travel+vec2(-direction.y,direction.x)*spin+vec2(0.,age*age*24.))*burst;
  }
  float size=uLook.x*(.45+seed*.45+energy*.9),len=size*(.5+energy*1.1);
  size=mix(size,uLook.x*(.5+depth*.9),amount);len=mix(len,0.,amount);len+=burst*(1.-exp(-max(0.,uStage.y)*5.))*uLook.x*3.;
  float rotation=seed*6.283+energy*.9+sin(uFlow.x*.8+seed*9.)*energy*.45;
  if(uStage.y>=0.)rotation=atan(orb.y,orb.x);
  float tintWeight=max(amount,burst*.85);int orbIndex=int(floor(fract(phi/6.283+seed*.18)*4.));
  vTint=mix(uColors[int(aStyle.x+.5)],uSphereColors[orbIndex]*(.62+depth*.38),tintWeight);
  vOpacity=mix(min(.92,.3+energy*.6),.18+depth*.72,amount)*uLook.y;vOpacity=max(vOpacity,burst*.65*uLook.y);
  gl_Position=vec4(position.x/uSize.x*2.-1.,1.-position.y/uSize.y*2.,0.,1.);vDiameter=len+max(.7,size*.68)+2.;gl_PointSize=vDiameter*uDpr;
  vShape=vec3(len,max(.7,size*.68),rotation);}`);
  const fs=shader(gl.FRAGMENT_SHADER,`#version 300 es
  precision highp float;in vec3 vShape;in vec3 vTint;in float vOpacity;in float vDiameter;out vec4 outColor;
  void main(){vec2 p=(gl_PointCoord-.5)*vDiameter;float c=cos(vShape.z),s=sin(vShape.z);p=mat2(c,-s,s,c)*p;
  float d=length(vec2(max(abs(p.x)-vShape.x*.5,0.),p.y))-vShape.y*.5;float aa=max(fwidth(d),.25);float a=(1.-smoothstep(-aa,aa,d))*vOpacity;
  outColor=vec4(vTint*a,a);}`);
  this.program=gl.createProgram();gl.attachShader(this.program,vs);gl.attachShader(this.program,fs);gl.linkProgram(this.program);gl.deleteShader(vs);gl.deleteShader(fs);
  if(!gl.getProgramParameter(this.program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(this.program));
  gl.useProgram(this.program);this.buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,this.buffer);
  for(const [name,size,offset] of [['aPosition',2,0],['aShape',3,8],['aStyle',2,20]]){const loc=gl.getAttribLocation(this.program,name);gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,size,gl.FLOAT,false,28,offset);}
  this.size=gl.getUniformLocation(this.program,'uSize');this.dpr=gl.getUniformLocation(this.program,'uDpr');this.colors=gl.getUniformLocation(this.program,'uColors[0]');
  this.pointer=gl.getUniformLocation(this.program,'uPointer');this.flow=gl.getUniformLocation(this.program,'uFlow');this.look=gl.getUniformLocation(this.program,'uLook');
  this.stage=gl.getUniformLocation(this.program,'uStage');this.orb=gl.getUniformLocation(this.program,'uOrb');this.sphereColors=gl.getUniformLocation(this.program,'uSphereColors[0]');
  gl.uniform3fv(this.sphereColors,['#536aee','#a358db','#ec6578','#daa72c'].flatMap(hex=>[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)/255)));
  gl.enable(gl.BLEND);gl.blendFunc(gl.ONE,gl.ONE_MINUS_SRC_ALPHA);canvas.dataset.renderer='webgl2';
 }
 draw(data,count,width,height,dpr,dark,settings){
  const colors=dark?['#8195ff','#4c8dff','#be9cfa','#9bb5d3']:['#2c64ed','#4072cc','#ea5c60','#c69a22'];
  const background=settings.background;
  if(this.gl){const gl=this.gl;gl.viewport(0,0,this.canvas.width,this.canvas.height);gl.clearColor(background[0]/255,background[1]/255,background[2]/255,1);gl.clear(gl.COLOR_BUFFER_BIT);gl.useProgram(this.program);gl.bindBuffer(gl.ARRAY_BUFFER,this.buffer);
   if(this.uploaded!==data){gl.bufferData(gl.ARRAY_BUFFER,data,gl.STATIC_DRAW);this.uploaded=data;}
   gl.uniform2f(this.pointer,settings.x,settings.y);gl.uniform4f(this.flow,settings.time,settings.radius,settings.speed,settings.force);gl.uniform3f(this.look,settings.size,settings.opacity,settings.motion);
   gl.uniform4f(this.stage,settings.stage.amount,settings.stage.age,settings.stage.startAmount,settings.stage.orbTime);gl.uniform3f(this.orb,settings.center.x,settings.center.y,settings.orbRadius);
   gl.uniform2f(this.size,width,height);gl.uniform1f(this.dpr,dpr);gl.uniform3fv(this.colors,colors.flatMap(hex=>[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)/255)));gl.drawArrays(gl.POINTS,0,count);return;
  }
  const ctx=this.ctx;if(!ctx)return;ctx.setTransform(dpr,0,0,dpr,0,0);ctx.globalAlpha=1;ctx.fillStyle=`rgb(${background.join(',')})`;ctx.fillRect(0,0,width,height);ctx.lineCap='round';
  // Quantized opacity and width allow all particles to be stroked in 24 batches.
  for(let color=0;color<4;color++)for(let level=0;level<6;level++){
   ctx.beginPath();ctx.strokeStyle=colors[color];ctx.globalAlpha=(level+.5)/6;ctx.lineWidth=level<2?.8:1.5;
   for(let i=0;i<count;i++){const j=i*7;if(data[j+5]!==color||Math.min(5,Math.floor(data[j+6]*6))!==level)continue;const x=data[j],y=data[j+1],len=data[j+2]*.5,angle=data[j+4],dx=Math.cos(angle)*len,dy=Math.sin(angle)*len;ctx.moveTo(x-dx,y-dy);ctx.lineTo(x+dx,y+dy);}ctx.stroke();
  }ctx.globalAlpha=1;
 }
 dispose(){if(this.gl){this.gl.deleteBuffer(this.buffer);this.gl.deleteProgram(this.program);}}
}
