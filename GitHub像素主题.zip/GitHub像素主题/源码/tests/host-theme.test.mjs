import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

// Exercise the real built client against the host services, with no chat data.
test('uses native dark scheme, registers token pairs, and restores all owned state on unload',()=>{
  class Node {
    constructor(tag='div'){this.tag=tag;this.children=[];this.attributes=new Map();this.dataset={};this.style={values:new Map(),getPropertyValue(k){return this.values.get(k)||'';},getPropertyPriority(){return '';},setProperty(k,v){this.values.set(k,v);},removeProperty(k){this.values.delete(k);}};}
    append(...nodes){for(const n of nodes){this.children.push(n);if(n&&typeof n==='object')n.parent=this;}}
    setAttribute(k,v){this.attributes.set(k,String(v));}getAttribute(k){return this.attributes.get(k)??null;}removeAttribute(k){this.attributes.delete(k);}hasAttribute(k){return this.attributes.has(k);}toggleAttribute(k,v){if(v)this.setAttribute(k,'');else this.removeAttribute(k);}
    addEventListener(){}removeEventListener(){}remove(){if(this.parent)this.parent.children=this.parent.children.filter(n=>n!==this);}
  }
  const document={documentElement:new Node('html'),body:new Node('body'),head:new Node('head'),hidden:false,createElement:tag=>new Node(tag),querySelectorAll:()=>[],addEventListener(){},removeEventListener(){}};
  const events=new Map(),layers=new Map();let installs=0,statusSubscriptions=0;
  const statusSource={getSnapshot:()=>new Map(),subscribe(){statusSubscriptions++;return()=>{statusSubscriptions--;};}};
  const legacyUi=new Proxy({},{has:()=>true,get(){throw Error('sessionStatus requires a separately injected service');}});
  const theme={getTheme:()=>({preference:'dark',active:{colorScheme:'dark'}}),overrideTokens(id,tokens){installs++;layers.set(id,tokens);for(const f of events.get('theme/change')||[])f();let live=true;return()=>{if(live){live=false;layers.delete(id);for(const f of events.get('theme/change')||[])f();}};}};
  let entry;
  const sandbox={window:{__ModuleLoader__:{load:x=>entry=x}},document,Element:Node,MutationObserver:class{observe(){}disconnect(){}},matchMedia:()=>({matches:false,addEventListener(){},removeEventListener(){}}),localStorage:{getItem:()=>null,setItem(){}},requestAnimationFrame:()=>1,cancelAnimationFrame(){},setTimeout,clearTimeout,console};
  vm.runInNewContext(fs.readFileSync(new URL('../lib/client.js',import.meta.url),'utf8'),sandbox);
  const topEffects=[];
  const ctx={get:name=>name==='theme'?theme:null,effect(fn){topEffects.push(fn());},inject(names,fn){const effects=[];fn({get:name=>{if(name==='theme')return theme;if(name==='uiSession')return legacyUi;if(name==='uiSession.sessionStatus'){if(names.includes(name))return statusSource;throw Error('Service not injected');}return null;},effect(fn){effects.push(fn());},on(name,listener){if(!events.has(name))events.set(name,new Set());events.get(name).add(listener);return()=>events.get(name).delete(listener);}});let live=true;return{dispose(){if(!live)return;live=false;for(const stop of effects.reverse())stop?.();}};}};
  entry.factory(()=>{throw Error('React is not present in this host mock');}).apply(ctx);
  assert.equal(document.documentElement.getAttribute('data-gpx-dark'),'true');
  assert.equal(layers.size,1);const pairs=layers.get('dsh-github-pixel-theme');
  assert.equal(pairs['--dsw-alias-label-primary'].light,'#e6edf3');assert.equal(pairs['--dsw-alias-bg-base'].dark,'#0d1117');
  assert.ok(installs<=2,'theme/change should not cause recursive token registrations');
  assert.equal(statusSubscriptions,1,'should bind the separate session-status service without reading an unsafe legacy property');
  for(const stop of topEffects.reverse())stop();
  assert.equal(layers.size,0);assert.equal(document.documentElement.hasAttribute('data-gpx'),false);
  assert.equal(statusSubscriptions,0,'session-status listeners should be released exactly once');
  assert.equal(document.documentElement.style.values.size,0);assert.equal(document.body.children.length,0);assert.equal(document.head.children.length,0);
});
