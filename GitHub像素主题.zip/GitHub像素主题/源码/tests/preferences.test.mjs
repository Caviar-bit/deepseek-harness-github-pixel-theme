import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {ID, DEFAULTS, normalize, readProfile, resolveSurfaces, contrastRatio} from '../src/preferences.js';
test('clamps hostile or obsolete imported settings to supported values',()=>{
  const got=normalize({cell:1e9,lifetime:-30,fps:Infinity,scope:'everything',enabled:'false',accent:'url(javascript:bad)',customDark:'#ff00aa',fontSize:16.4,unknown:1});
  assert.equal(got.cell,32);assert.equal(got.lifetime,120);assert.equal(got.fps,DEFAULTS.fps);
  assert.equal(got.scope,'home');assert.equal(got.enabled,true);assert.equal(got.accent,DEFAULTS.accent);
  assert.equal(got.customDark,'#ff00aa');assert.equal(got.fontSize,16);assert.equal('unknown' in got,false);
  assert.deepEqual(normalize(null),DEFAULTS);assert.deepEqual(normalize([]),DEFAULTS);
});
test('portable profile round-trips and rejects other formats',()=>{
  const preferences=normalize({...DEFAULTS,palette:'dusk',mode:'dark',clickBurst:true});
  assert.deepEqual(readProfile(JSON.stringify({theme:ID,version:1,preferences})),preferences);
  for(const input of ['{}','null','{broken',JSON.stringify({theme:'other',version:1,preferences:{}}),JSON.stringify({theme:ID,version:2,preferences:{}}),' '.repeat(65537)]) assert.throws(()=>readProfile(input));
});
test('client registers the correct module and server-side apply is harmless',()=>{
  let module;
  vm.runInNewContext(fs.readFileSync(new URL('../lib/client.js',import.meta.url),'utf8'),{window:{__ModuleLoader__:{load:entry=>{module=entry;}}}});
  assert.equal(module.id,ID);const exports=module.factory(()=>{throw Error('No browser packages');});
  assert.equal(typeof exports.apply,'function');assert.doesNotThrow(()=>exports.apply({}));
});
test('package entry points and skin wiring agree',()=>{
  const root=new URL('../',import.meta.url), pkg=JSON.parse(fs.readFileSync(new URL('package.json',root),'utf8'));
  assert.equal(pkg.name,ID);for(const entry of [pkg.main,pkg.exports['./client'],pkg.dsh.bundle.patch]) assert.ok(fs.existsSync(new URL(entry,root)));
  assert.equal(JSON.parse(fs.readFileSync(new URL('skin.json',root),'utf8')).id,ID);
  const patch=fs.readFileSync(new URL('cordis.patch.yml',root),'utf8');assert.match(patch,/id: github-pixel-theme/);assert.ok(patch.includes('name: '+ID));
});
test('each surface has independent light and dark backgrounds without changing the pixel palette',()=>{
  const prefs=normalize({...DEFAULTS,mainBackground:'custom',sidebar:'custom',cardBackground:'custom',customLight:'#f5f0e8',customDark:'#151030',customSidebarLight:'#102030',customSidebarDark:'#aabbcc',customCardLight:'#fff8ee',customCardDark:'#132231'});
  const light=resolveSurfaces(prefs,false),dark=resolveSurfaces(prefs,true);
  assert.equal(light.bg,'#f5f0e8');assert.equal(light.sidebar,'#102030');assert.equal(light.card,'#fff8ee');
  assert.equal(dark.bg,'#151030');assert.equal(dark.sidebar,'#aabbcc');assert.equal(dark.card,'#132231');
  assert.equal(prefs.palette,'github');
  for(const surface of [light,dark]) {
    for(const [background,tone] of [[surface.bg,surface.main],[surface.sidebar,surface.sidebarTone],[surface.card,surface.cardTone]]) {
      assert.ok(contrastRatio(background,tone.text)>=4.5);assert.ok(contrastRatio(background,tone.muted)>=4.5);
    }
  }
  assert.equal(light.sidebarTone.dark,true);assert.equal(dark.sidebarTone.dark,false);
});
test('legacy profile defaults and follow-canvas mode remain compatible',()=>{
  const legacy=normalize({palette:'custom',customLight:'#f1eddd',sidebar:'canvas'});
  const surface=resolveSurfaces(legacy,false);
  assert.equal(surface.bg,'#f1eddd');assert.equal(surface.sidebar,surface.bg);
  const imported=readProfile(JSON.stringify({theme:ID,version:1,preferences:legacy}));
  assert.deepEqual(imported,legacy);
  const invalid=normalize({customSidebarLight:'red',customCardDark:'#fff',sidebar:'unknown',mainBackground:'unknown'});
  assert.equal(invalid.customSidebarLight,DEFAULTS.customSidebarLight);assert.equal(invalid.sidebar,'soft');
});
test('automatic text contrast remains readable across arbitrary user backgrounds',()=>{
  for(let r=0;r<256;r+=17)for(let g=0;g<256;g+=17)for(let b=0;b<256;b+=17) {
    const color='#'+[r,g,b].map(c=>c.toString(16).padStart(2,'0')).join('');
    const prefs=normalize({...DEFAULTS,mainBackground:'custom',customLight:color});
    const {main}=resolveSurfaces(prefs,false);
    assert.ok(contrastRatio(color,main.text)>=4.5, color+' text');assert.ok(contrastRatio(color,main.muted)>=4.5,color+' muted');
  }
});
