// This source is joined with preferences.js and theme.css by build.mjs.
function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}
function mark() {
  const node=element('span','gpx-mark'); node.setAttribute('aria-hidden','true');
  for(let i=0;i<4;i++) node.append(element('i'));
  return node;
}
function service(ctx,name) {try {return ctx.get?.(name) ?? ctx[name];} catch {return null;}}

class PixelField {
  constructor(root,read,onDark,preview=false) {
    this.kind='github';this.root=root; this.read=read; this.onDark=onDark; this.preview=preview;
    this.pixels=new Map(); this.frame=0; this.last=0; this.previous=null; this.visible=true; this.dead=false;
    this.canvas=element('canvas','gpx-canvas'); this.canvas.setAttribute('aria-hidden','true');
    this.canvas.setAttribute('role','presentation'); root.append(this.canvas);
    this.priorSurface=root.getAttribute('data-gpx-surface'); root.setAttribute('data-gpx-surface','');
    this.context=this.canvas.getContext('2d',{alpha:true});
    this.move=e=>this.pointer(e,false); this.down=e=>this.pointer(e,true); this.leave=()=>{this.previous=null;};
    root.addEventListener('pointermove',this.move,{passive:true});
    root.addEventListener('pointerdown',this.down,{passive:true});
    root.addEventListener('pointerleave',this.leave,{passive:true});
    this.resizeObserver=new ResizeObserver(()=>this.resize()); this.resizeObserver.observe(root);
    this.intersection=new IntersectionObserver(entries=>{this.visible=entries[0]?.isIntersecting??false;this.wake();}); this.intersection.observe(root);
    this.resize();
  }
  reduced() {return this.read().motion==='reduced'||matchMedia('(prefers-reduced-motion: reduce)').matches;}
  resize() {
    const box=this.root.getBoundingClientRect(); this.width=Math.ceil(box.width); this.height=Math.ceil(box.height);
    // Cap backing pixels on high-DPI and tall embedded panels.
    this.dpr=Math.max(0.5,Math.min(devicePixelRatio||1,1.75,4096/Math.max(this.width,this.height,1)));
    this.canvas.width=Math.round(this.width*this.dpr); this.canvas.height=Math.round(this.height*this.dpr);
    this.pixels.clear(); this.previous=null; this.wake();
  }
  add(x,y,now) {
    const p=this.read(), cols=Math.ceil(this.width/p.cell), rows=Math.ceil(this.height/p.cell);
    if(x<0||y<0||x>=cols||y>=rows) return;
    const key=x+','+y;
    if(this.pixels.has(key)) return;
    const colors=PALETTES[p.palette].colors;
    this.pixels.set(key,{x,y,born:now,color:p.palette==='custom'&&Math.random()<0.5?p.accent:colors[Math.floor(Math.random()*colors.length)]});
    while(this.pixels.size>p.maxPixels) this.pixels.delete(this.pixels.keys().next().value);
  }
  pointer(event,click) {
    const p=this.read();
    if(!p.enabled||this.reduced()||document.hidden||!this.visible) return;
    if(event.target instanceof Element && event.target.closest('button,a,input,textarea,select,[contenteditable],[data-composer-card],[role="menu"],[role="dialog"]') && !this.preview) {this.previous=null;return;}
    if(click&&!p.clickBurst||!click&&!p.trail) return;
    const r=this.root.getBoundingClientRect();
    const x=Math.floor((event.clientX-r.left)/p.cell), y=Math.floor((event.clientY-r.top)/p.cell), now=performance.now();
    if(click) {
      for(let j=-3;j<=3;j++) for(let i=-3;i<=3;i++) if(Math.abs(i)+Math.abs(j)<=3&&Math.random()>.3) this.add(x+i,y+j,now);
    } else {
      const last=this.previous;
      const distance=last?Math.max(Math.abs(x-last.x),Math.abs(y-last.y)):1;
      const steps=Math.min(40,distance);
      for(let i=1;i<=steps;i++) this.add(Math.round(last?last.x+(x-last.x)*i/steps:x),Math.round(last?last.y+(y-last.y)*i/steps:y),now);
      this.previous={x,y};
    }
    this.wake();
  }
  wake() {
    if(this.dead||this.frame||document.hidden||!this.visible) return;
    this.frame=requestAnimationFrame(now=>this.paint(now));
  }
  update() {
    this.pixels.clear(); this.previous=null; this.last=0; this.wake();
  }
  paint(now) {
    this.frame=0;
    if(this.dead||!this.context||document.hidden||!this.visible) return;
    const p=this.read(), ctx=this.context, dark=this.onDark();
    if(this.reduced()) this.pixels.clear();
    if(now-this.last<1000/p.fps && this.pixels.size) {this.wake();return;}
    this.last=now;
    const size=p.cell, w=this.width, h=this.height;
    ctx.setTransform(this.dpr,0,0,this.dpr,0,0); ctx.clearRect(0,0,w,h);
    ctx.lineWidth=1/this.dpr;
    const grid=ctx.createLinearGradient(0,0,0,Math.max(1,h));
    const opacity=p.gridOpacity/100;
    const rgb=dark?'180,198,218':'105,122,145';
    grid.addColorStop(0,`rgba(${rgb},${opacity*.15})`);
    grid.addColorStop(.45,`rgba(${rgb},${opacity*.7})`);
    grid.addColorStop(1,`rgba(${rgb},${opacity})`);
    ctx.strokeStyle=grid; ctx.beginPath();
    for(let x=0;x<w;x+=size) {ctx.moveTo(x+.5/this.dpr,0);ctx.lineTo(x+.5/this.dpr,h);}
    for(let y=0;y<h;y+=size) {ctx.moveTo(0,y+.5/this.dpr);ctx.lineTo(w,y+.5/this.dpr);}
    ctx.stroke();
    if(p.corners && w>size*10 && h>size*8) {
      const colors=PALETTES[p.palette].colors;
      for(const side of [2,Math.floor(w/size)-4]) for(let i=0;i<4;i++) {
        ctx.globalAlpha=.8;ctx.fillStyle=colors[i%colors.length];ctx.fillRect((side+i%2)*size,(2+Math.floor(i/2))*size,size,size);
      }
    }
    for(const [key,pixel] of this.pixels) {
      const age=(now-pixel.born)/p.lifetime;
      if(age>=1) {this.pixels.delete(key);continue;}
      const alpha=age<.45?1:Math.max(0,(1-age)/.55);
      ctx.globalAlpha=alpha*p.intensity/100; ctx.fillStyle=pixel.color;
      ctx.fillRect(pixel.x*size,pixel.y*size,size,size);
    }
    ctx.globalAlpha=1;
    if(this.pixels.size) this.wake();
  }
  dispose() {
    this.dead=true; cancelAnimationFrame(this.frame); this.frame=0;
    this.resizeObserver.disconnect();this.intersection.disconnect();
    this.root.removeEventListener('pointermove',this.move);this.root.removeEventListener('pointerdown',this.down);this.root.removeEventListener('pointerleave',this.leave);
    this.canvas.remove();this.pixels.clear();
    if(this.priorSurface===null) this.root.removeAttribute('data-gpx-surface');else this.root.setAttribute('data-gpx-surface',this.priorSurface);
  }
}

function apply(ctx) {
  if(typeof document==='undefined') return;
  let stop=null;
  const install=()=>{stop=mountTheme(ctx);return()=>{stop?.();stop=null;};};
  if(typeof ctx.effect==='function') ctx.effect(install,ID);else install();
}

function mountTheme(ctx) {
  let dead=false, prefs=normalize({}), form=null, offForm=null, offDirectory=null, write=Promise.resolve(), pendingWrites=0, status='设置保存在当前浏览器';
  let themeApi=service(ctx,'theme'), tokenOff=null, tokenSignature='';
  let claudeFeatures=null;
  const listeners=new Set(), fields=new Map(), cleanup=[], root=document.documentElement;
  const storageKey=ID+':preferences:v1';
  try {prefs=normalize(JSON.parse(localStorage.getItem(storageKey)||'{}'));} catch {}
  const oldAttributes=new Map(['data-gpx','data-gpx-dark','data-gpx-reduced','data-gpx-hidden'].map(k=>[k,root.getAttribute(k)]));
  const oldProperties=new Map();
  const style=element('style');style.dataset.gpxStyle='';style.textContent=CSS;document.head.append(style);
  const systemDark=matchMedia('(prefers-color-scheme: dark)'), reduced=matchMedia('(prefers-reduced-motion: reduce)');
  function dark() {
    if(prefs.mode==='dark') return true;
    if(prefs.mode==='light') return false;
    const theme=themeApi;
    try {const value=theme?.getTheme?.();const scheme=value?.active?.colorScheme??value?.resolved??value?.mode;if(scheme==='dark') return true;if(scheme==='light') return false;} catch {}
    return document.body.hasAttribute('data-ds-dark-theme')||systemDark.matches;
  }
  function variable(name,value) {
    if(!oldProperties.has(name)) oldProperties.set(name,[root.style.getPropertyValue(name),root.style.getPropertyPriority(name)]);
    root.style.setProperty(name,value);
  }
  function updateAppearance() {
    if(dead) return;
    const isDark=dark(),surface=resolveSurfaces(prefs,isDark),{bg,panel,card,sidebar,main,cardTone,sidebarTone}=surface;
    root.toggleAttribute('data-gpx',prefs.enabled); root.setAttribute('data-gpx-dark',String(main.dark&&prefs.enabled));
    root.setAttribute('data-gpx-reduced',String(prefs.motion==='reduced'||reduced.matches));root.setAttribute('data-gpx-hidden',String(document.hidden));
    variable('--gpx-star-image',`url("${CLAUDE_STAR}")`);variable('--gpx-star-color',prefs.starColor);
    variable('--gpx-bg',bg);variable('--gpx-panel',panel);variable('--gpx-card',card);variable('--gpx-surface-card',card);
    variable('--gpx-text',main.text);variable('--gpx-muted',main.muted);variable('--gpx-border',main.border);
    variable('--gpx-main-muted',main.muted);variable('--gpx-accent',prefs.accent);variable('--gpx-sidebar',sidebar);
    for(const [name,tone,background] of [['sidebar',sidebarTone,sidebar],['card',cardTone,card]]) {
      variable('--gpx-'+name+'-text',tone.text);variable('--gpx-'+name+'-muted',tone.muted);variable('--gpx-'+name+'-border',tone.border);
      variable('--gpx-'+name+'-panel',mixColor(background,tone.text,.05));variable('--gpx-'+name+'-scheme',tone.dark?'dark':'light');
    }
    variable('--gpx-size',prefs.fontSize+'px');variable('--gpx-width',prefs.contentWidth+'px');variable('--gpx-radius',prefs.radius+'px');
    variable('--gpx-font',prefs.font==='mono'?"'Cascadia Code',Consolas,'Microsoft YaHei',monospace":prefs.font==='sans'?"Arial,'Microsoft YaHei',sans-serif":"-apple-system,BlinkMacSystemFont,'Segoe UI','Microsoft YaHei',sans-serif");
    // The native theme service arbitrates token layers, including portaled menus.
    // Set the signature before calling it: theme/change may fire synchronously.
    const values={
      '--dsw-alias-bg-base':bg,'--dsw-alias-bg-l1':panel,
      '--dsw-specific-sidebar-fill':sidebar,'--dsw-specific-sidebar-tint':sidebar,
      '--dsw-specific-sidebar-wash-top':'transparent','--dsw-specific-sidebar-wash-top-clear':'transparent',
      '--dsw-specific-sidebar-wash-bottom':'transparent','--dsw-specific-sidebar-wash-bottom-clear':'transparent',
      '--dsw-alias-bg-l2':card,'--dsw-alias-bg-module':card,
      '--dsw-alias-label-primary':main.text,'--dsw-alias-label-secondary':main.muted,
      '--dsw-alias-label-tertiary':main.muted,'--dsw-alias-border-l1':main.border,
      '--dsw-alias-border-l2':main.border,'--dsw-alias-link':prefs.accent,
      '--dsw-alias-button-primary-fill':prefs.accent,'--dsw-alias-label-primary-foreground':'#ffffff'
    };
    const signature=prefs.enabled?JSON.stringify(values):'off';
    if(themeApi?.overrideTokens&&signature!==tokenSignature) {
      tokenSignature=signature;tokenOff?.();tokenOff=null;
      if(prefs.enabled) {try{tokenOff=themeApi.overrideTokens(ID,Object.fromEntries(Object.entries(values).map(([name,value])=>[name,{light:value,dark:value}])));}catch{status='当前宿主不支持颜色覆盖层，使用基础样式。';}}
    }
    reconcile();for(const field of fields.values()) field.update();claudeFeatures?.sync();
    for(const listener of listeners) listener();
  }
  function readStoredForm() {
    if(dead||!form||pendingWrites) return;
    const snapshot=form.getSnapshot();
    if(snapshot?.status!=='ready') return;
    prefs=normalize(snapshot.value?.preferences);status='已保存到 Harness 配置';
    try{localStorage.setItem(storageKey,JSON.stringify(prefs));}catch{}
    updateAppearance();
  }
  function bindSettings(scope) {
    if(form||dead) return;
    const forms=service(scope,'configForms');if(!forms?.get) return;
    const directory=forms.describe?.();
    const attempt=()=>{
      if(dead||form) return;
      const namespaces=directory?.getSnapshot?.()?.view?.namespaces;
      const rawEntry=ctx.fiber?.entry?.id;
      const entry=typeof rawEntry==='string'?rawEntry.split(':').pop():null;
      const candidates=[entry,ENTRY,ID].filter(Boolean);
      const namespace=Array.isArray(namespaces)?candidates.find(n=>namespaces.some(row=>row.ns===n)):ENTRY;
      if(!namespace) return;
      const candidate=forms.get(namespace);if(!candidate?.getSnapshot) return;
      form=candidate;offDirectory?.();offDirectory=null;
      offForm=form.subscribe?.(readStoredForm);readStoredForm();
    };
    if(directory?.subscribe) offDirectory=directory.subscribe(attempt);
    directory?.ensure?.();attempt();
  }
  function change(patch) {
    if('customLight' in patch||'customDark' in patch) patch={...patch,mainBackground:'custom'};
    if('customSidebarLight' in patch||'customSidebarDark' in patch) patch={...patch,sidebar:'custom'};
    if('customCardLight' in patch||'customCardDark' in patch) patch={...patch,cardBackground:'custom'};
    if('palette' in patch) patch={...patch,mainBackground:'theme',sidebar:'soft',cardBackground:'auto'};
    prefs=normalize({...prefs,...patch}); status='正在保存…';
    try {localStorage.setItem(storageKey,JSON.stringify(prefs));} catch {status='浏览器存储不可用，本次会话仍然有效';}
    const next={...prefs};pendingWrites++; updateAppearance();
    write=write.then(async()=>{
      if(dead) {pendingWrites--;return;}
      if(form?.getSnapshot()?.status==='ready') {
        try {
          const result=await form.set('preferences',next);
          if(result===false) throw new Error('Harness 拒绝了这次设置写入');
          status='已保存到 Harness 配置';
        } catch {status='Harness 保存失败，已保留本机副本；导出配置可备份。';}
      } else status='已保存到当前浏览器 · 可导出配置备份';
      pendingWrites--;
      if(!dead) for(const listener of listeners) listener();
    });
  }
  function reconcile() {
    if(dead) return;
    const wanted=new Set();
    const scope=prefs.backgroundEffect==='antigravity'?prefs.particleScope:prefs.scope;
    if(prefs.enabled&&scope!=='off') {
      const selector=scope==='all'?(prefs.backgroundEffect==='antigravity'?'[data-phase="hero"],[data-phase="settling"],[data-phase="active"]':'[data-phase="hero"],[data-phase="active"]'):'[data-phase="hero"]';
      for(const node of document.querySelectorAll(selector)) {
        if(node.closest('[data-pane="sidebar"],[data-slot="sidebar"],[data-slot="sidebar.right"],[data-slot="sidebar.chat"]')) continue;
        if(node.parentElement?.closest('[data-phase="hero"],[data-phase="active"]')) continue;
        wanted.add(node);
      }
    }
    for(const [node,field] of fields) if(!wanted.has(node)||field.kind!==prefs.backgroundEffect) {
      if(prefs.enabled&&scope!=='off'&&field.kind===prefs.backgroundEffect&&node.isConnected&&field.isBursting?.()){wanted.add(node);continue;}
      field.dispose();fields.delete(node);
    }
    for(const node of wanted) if(!fields.has(node)) fields.set(node,createBackgroundField(node,()=>prefs,dark));
  }
  let reconcileFrame=0;
  const burstEnd=()=>{if(!reconcileFrame)reconcileFrame=requestAnimationFrame(()=>{reconcileFrame=0;reconcile();});};
  document.addEventListener('gpx-burst-end',burstEnd);cleanup.push({dispose:()=>document.removeEventListener('gpx-burst-end',burstEnd)});
  const observer=new MutationObserver(records=>{
    if(records.every(r=>r.target instanceof Element && (r.target.closest('.gpx-settings,.gpx-dialog,.gpx-pet,.gpx-reply-signature,.gpx-running-star')||r.target.classList.contains('gpx-canvas')))) return;
    if(!reconcileFrame) reconcileFrame=requestAnimationFrame(()=>{reconcileFrame=0;reconcile();});
  });
  observer.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['data-phase']});
  const themeObserver=new MutationObserver(()=>updateAppearance());
  themeObserver.observe(document.body,{attributes:true,attributeFilter:['data-ds-dark-theme']});
  const visibility=()=>{root.setAttribute('data-gpx-hidden',String(document.hidden));for(const field of fields.values()) {field.pixels?.clear();field.previous=null;field.last=0;if(document.hidden) {cancelAnimationFrame(field.frame);field.frame=0;} else field.wake();}claudeFeatures?.sync();};
  const media=()=>updateAppearance();
  document.addEventListener('visibilitychange',visibility);systemDark.addEventListener('change',media);reduced.addEventListener('change',media);
  let dialog=null,offDialog=null;
  const launch=element('button','gpx-launch');launch.type='button';launch.title='GitHub Pixel · 像素主题设置';launch.setAttribute('aria-label','打开像素主题设置');launch.append(mark());document.body.append(launch);
  launch.addEventListener('click',()=>{
    if(dialog?.open) return;
    dialog=element('dialog','gpx-dialog');dialog.setAttribute('aria-label','GitHub Pixel 主题设置');
    const head=element('div','gpx-dialog-head'),label=element('strong',null,'GitHub Pixel');label.prepend(mark());
    const close=element('button','gpx-close','×');close.type='button';close.setAttribute('aria-label','关闭主题设置');close.onclick=()=>dialog.close();head.append(label,close);dialog.append(head);
    const container=element('div');dialog.append(container);document.body.append(dialog);offDialog=mountSettings(container);
    dialog.addEventListener('close',()=>{offDialog?.();offDialog=null;dialog.remove();dialog=null;launch.focus();},{once:true});dialog.showModal();
  });

  function mountSettings(container) {
    const shell=element('section','gpx-settings');container.append(shell);
    shell.append(element('h2',null,'像素栖地。'),element('p',null,'让每一次灵感经过，都留下颜色。'));
    const tabs=element('div','gpx-tabs');tabs.setAttribute('role','tablist');tabs.setAttribute('aria-label','主题设置分类');shell.append(tabs);
    const content=element('div');content.setAttribute('role','tabpanel');shell.append(content);
    const foot=element('div','gpx-status');foot.setAttribute('role','status');foot.setAttribute('aria-live','polite');shell.append(foot);
    const controls=[], buttons=[];let active='appearance', preview=null, disposed=false,perfTimer=null;
    const unique='gpx-'+Math.random().toString(36).slice(2);
    function row(key,label,description,type,options) {
      const line=element('div','gpx-row'),text=element('label',null,label),control=element(type==='select'?'select':'input');control.id=unique+'-'+key;text.htmlFor=control.id;
      if(description) text.append(element('small',null,description));
      if(type==='select') for(const [value,title] of options) {const option=element('option',null,title);option.value=value;control.append(option);}
      else control.type=type;
      let output=null,hex=null;
      if(type==='range') {const [min,max,step,unit]=options;control.min=min;control.max=max;control.step=step;const wrap=element('div','gpx-slider');output=element('output');wrap.append(control,output);line.append(text,wrap);control.addEventListener('input',()=>{output.value=control.value+unit;change({[key]:Number(control.value)});});}
      else if(type==='color') {
        const wrap=element('div','gpx-color-control');hex=element('input');hex.type='text';hex.maxLength=7;hex.spellcheck=false;hex.setAttribute('aria-label',label+' 十六进制颜色');
        hex.addEventListener('input',()=>{hex.setCustomValidity('');const value=hex.value.trim().replace(/^#?/,'#');if(/^#[0-9a-f]{6}$/i.test(value))change({[key]:value});});
        hex.addEventListener('change',()=>{const value=hex.value.startsWith('#')?hex.value:'#'+hex.value;if(/^#[0-9a-f]{6}$/i.test(value)){hex.setCustomValidity('');change({[key]:value});}else{hex.setCustomValidity('请输入六位十六进制颜色，例如 #f5f0e8');hex.reportValidity();}});
        control.addEventListener('input',()=>{hex.setCustomValidity('');hex.value=control.value;change({[key]:control.value});});
        wrap.append(control,hex);line.append(text,wrap);
      } else {line.append(text,control);control.addEventListener('change',()=>{change({[key]:type==='checkbox'?control.checked:control.value});if(key==='backgroundEffect')draw();});}
      const refresh=()=>{if(type==='checkbox') control.checked=prefs[key];else control.value=String(prefs[key]);if(hex&&document.activeElement!==hex) hex.value=prefs[key];if(output) output.value=prefs[key]+options[3];};
      controls.push(refresh);refresh();content.append(line);
    }
    function draw() {
      clearInterval(perfTimer);perfTimer=null;
      preview?.dispose();preview=null;controls.length=0;content.replaceChildren();
      for(const button of buttons) {button.setAttribute('aria-selected',String(button.dataset.tab===active));button.tabIndex=button.dataset.tab===active?0:-1;}
      content.id=unique+'-panel';content.setAttribute('aria-labelledby',unique+'-'+active);
      if(active==='appearance') {
        row('enabled','启用主题','关闭后恢复 Harness 原生界面；右下角仍可重新开启。','checkbox');
        row('mode','亮暗模式','自动跟随宿主或系统外观。','select',[['system','跟随系统 / 宿主'],['light','浅色'],['dark','深色']]);
        const presets=element('div','gpx-presets');content.append(presets);
        for(const key of ['github','deepseek','forest','dusk']) {
          const p=PALETTES[key],button=element('button','gpx-preset');button.type='button';button.dataset.palette=key;
          const swatches=element('span','gpx-swatches');for(const color of p.colors.slice(0,4)) {const dot=element('i');dot.style.background=color;swatches.append(dot);}button.append(swatches,document.createTextNode(p.name));
          button.onclick=()=>change({palette:key,accent:p.accent});controls.push(()=>button.setAttribute('aria-pressed',String(prefs.palette===key)));presets.append(button);
        }
        row('palette','配色方案','切换方案会恢复方案底色；可在“底色”中分别调整。','select',Object.entries(PALETTES).map(([id,p])=>[id,p.name]));
        row('accent','强调色','按钮、输入框焦点与自定义像素使用此颜色。','color');
      } else if(active==='backgrounds') {
        content.append(element('div','gpx-note','主界面、侧边栏和输入框可以分别选色。修改颜色后自动启用该区域的自定义底色，文字深浅随底色调整。'));
        row('mainBackground','主界面底色','影响新会话页、聊天区和主窗口画布。','select',[['theme','跟随配色方案'],['custom','自定义']]);
        row('customLight','主界面 · 浅色模式',null,'color');row('customDark','主界面 · 深色模式',null,'color');
        row('sidebar','侧边栏底色',null,'select',[['soft','柔和分区'],['canvas','与主界面一致'],['custom','自定义']]);
        row('customSidebarLight','侧边栏 · 浅色模式',null,'color');row('customSidebarDark','侧边栏 · 深色模式',null,'color');
        row('cardBackground','输入框和卡片底色','同时用于主题设置面板和菜单。','select',[['auto','自动搭配'],['custom','自定义']]);
        row('customCardLight','输入框和卡片 · 浅色模式',null,'color');row('customCardDark','输入框和卡片 · 深色模式',null,'color');
      } else if(active==='pixels') {
        row('backgroundEffect','背景互动效果','两种效果可随时切换；底色、宠物与星芒保持独立。','select',[['github','GitHub · 像素网格'],['antigravity','Antigravity · 反重力粒子']]);
        const box=element('div','gpx-preview');box.append(element('span',null,'在这里划过，试试看'));content.append(box);preview=createBackgroundField(box,()=>prefs,dark,true);
        row(prefs.backgroundEffect==='antigravity'?'particleScope':'scope','显示范围',prefs.backgroundEffect==='antigravity'?'粒子默认延续到聊天页，发送后继续跟随鼠标。':'默认只在新会话页显示。','select',[['home','仅新会话'],['all','新会话与聊天页'],['off','关闭背景']]);
        if(prefs.backgroundEffect==='github'){row('trail','鼠标像素拖尾','彩色方块跟随指针经过的网格。','checkbox');row('clickBurst','点击扩散','在空白处单击或轻触，散开一簇像素。','checkbox');
        row('corners','角落彩色方块','静态的四色定位点。','checkbox');
        row('cell','像素大小',null,'range',[6,32,1,'px']);row('lifetime','消退时间',null,'range',[120,2000,20,'ms']);
        row('intensity','色块强度',null,'range',[10,100,1,'%']);row('gridOpacity','网格可见度',null,'range',[0,30,1,'%']);
        }else{
        row('particleOrb','输入聚团 · 发送爆散','鼠标进入输入框或输入时聚成松散流动的不规则立体粒子团；点击发送后爆散并恢复鼠标互动。','checkbox');
        row('particleCount','粒子数量','会依据可用面积限制数量。','range',[600,16000,200,'颗']);
        row('particleRadius','扰动半径',null,'range',[60,300,10,'px']);
        row('particleForce','反重力强度',null,'range',[20,200,10,'%']);
        row('particleSpeed','自然流动速度',null,'range',[0,100,5,'%']);
        row('particleSize','粒子大小',null,'range',[1,5,1,'px']);
        row('particleOpacity','粒子可见度',null,'range',[10,100,5,'%']);
        const performanceNote=element('div','gpx-note');content.append(performanceNote);
        const performanceRefresh=()=>{const canvas=[...document.querySelectorAll('canvas[data-gpx-effect="antigravity"]')].find(n=>!n.closest('.gpx-settings'));const data=canvas?.dataset;
          performanceNote.textContent=root.getAttribute('data-gpx-reduced')==='true'?'减少动态效果：静态显示':data?`${data.renderer==='webgl2'?'WebGL2 · GPU 粒子运动与绘制':'Canvas 2D · 兼容模式'} · 实际 ${data.particleCount||'—'} 颗 · 当前约 ${data.measuredFps||'测量中'} FPS`:'启用背景后显示实际帧率';};
        performanceRefresh();perfTimer=setInterval(performanceRefresh,750);
        }
        row('motion','动效偏好','始终尊重操作系统的“减少动态效果”。','select',[['system','正常 · 尊重系统偏好'],['reduced','减少动态效果']]);
        if(prefs.backgroundEffect==='github')row('fps','帧率上限','空闲或窗口不可见时不持续绘制。','range',[20,60,5,'fps']);else row('particleFps','粒子帧率上限','独立于 GitHub 像素效果；实际帧率取决于硬件和窗口状态。','range',[30,120,10,'fps']);if(prefs.backgroundEffect==='github')row('maxPixels','最大拖尾像素',null,'range',[24,240,12,'格']);
      } else if(active==='companions') {
        const sample=element('div','gpx-companion-sample');sample.append(element('span','gpx-star gpx-running-star'),element('span',null,'Claude 星芒 · 输出时呼吸，回复结束后留下签名'));content.append(sample);
        row('petStyle','桌面宠物','Clawd 像素小螃蟹站在输入框上沿；单击互动，双击挠痒。','select',[['claude','Claude Code · Clawd'],['none','关闭']]);
        row('petScope','宠物显示范围',null,'select',[['all','新会话与聊天页'],['home','仅新会话']]);
        row('petSize','宠物大小',null,'range',[60,150,10,'%']);
        row('runningStyle','输出中状态','保留 Harness 的状态文字和计时，替换装饰图标。','select',[['claude','Claude Code · 呼吸星芒'],['native','Harness 原生']]);
        row('replySignatureStyle','回复签名','在已完成回复的末尾显示星芒，不写入消息正文。','select',[['claude','Claude Code · 星芒'],['none','关闭']]);
        row('signatureScope','签名显示范围',null,'select',[['latest','仅最新回复'],['all','每条已完成回复']]);
        row('starColor','星芒颜色','默认使用 Claude 陶土色。','color');
        content.append(element('div','gpx-note','宠物随思考、输出、工具调用和等待确认切换动画，完成后庆祝，长时间无操作会休息。减少动态效果时显示静态姿态。预览页顶部可演示对话状态。'));
      } else if(active==='layout') {
        row('font','界面字体',null,'select',[['system','系统字体'],['sans','简洁无衬线'],['mono','等宽字体']]);
        row('fontSize','正文大小',null,'range',[12,20,1,'px']);row('contentWidth','对话与输入框宽度','窄屏时由 Harness 自适应。','range',[600,1280,20,'px']);
        row('radius','卡片圆角',null,'range',[0,24,1,'px']);
        content.append(element('div','gpx-note','保留 Harness 的工作区、模型选择、附件、快捷键与消息滚动行为。主题只调整外观与装饰背景。'));
      } else {
        content.append(element('div','gpx-note','配置实时生效；可导出 JSON，在另一台设备或另一个浏览器导入。Harness 配置服务可用时，会保存到当前 profile。'));
        const actions=element('div','gpx-actions'),exportButton=element('button',null,'导出配置'),importButton=element('button',null,'导入配置'),resetButton=element('button',null,'恢复默认');
        const file=element('input');file.type='file';file.accept='.json,application/json';file.hidden=true;
        exportButton.onclick=()=>{const blob=new Blob([JSON.stringify({theme:ID,version:1,preferences:prefs},null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=element('a');a.href=url;a.download='github-pixel-settings.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
        importButton.onclick=()=>file.click();
        file.onchange=async()=>{try{const selected=file.files?.[0];if(!selected) return;if(selected.size>65536) throw new Error('配置文件不能超过 64KB。');change(readProfile(await selected.text()));}catch(error){status='导入失败：'+error.message;refresh();}finally{file.value='';}};
        let armed=false;resetButton.onclick=()=>{if(!armed){armed=true;resetButton.textContent='再次点击确认恢复';return;}change({...DEFAULTS});armed=false;resetButton.textContent='恢复默认';};
        actions.append(exportButton,importButton,resetButton,file);content.append(actions,element('p',null,'GitHub Pixel 1.4.1 · 为 DeepSeek Harness 制作。'),element('p',null,'灵感：github.com 首页 BackgroundGrid；交互代码独立实现，无外部网络请求。'));
      }
      refresh();
    }
    function refresh() {if(disposed) return;for(const control of controls) control();preview?.update();foot.textContent=status;}
    for(const [id,title] of [['appearance','外观'],['backgrounds','底色'],['pixels','互动背景'],['companions','宠物星芒'],['layout','布局字体'],['config','配置']]) {
      const button=element('button',null,title);button.type='button';button.dataset.tab=id;button.id=unique+'-'+id;button.setAttribute('role','tab');button.setAttribute('aria-controls',unique+'-panel');button.onclick=()=>{active=id;draw();};
      button.onkeydown=event=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) return;event.preventDefault();let index=buttons.indexOf(button);index=event.key==='Home'?0:event.key==='End'?buttons.length-1:(index+(event.key==='ArrowRight'?1:buttons.length-1))%buttons.length;buttons[index].click();buttons[index].focus();};
      tabs.append(button);buttons.push(button);
    }
    listeners.add(refresh);draw();
    return()=>{disposed=true;clearInterval(perfTimer);listeners.delete(refresh);preview?.dispose();shell.remove();};
  }
  function registerSlots(scope) {
    const slots=service(scope,'slots');if(!slots?.register||!slots?.inject) return;
    let React;try{React=require('react');}catch{return;}
    function Settings() {const ref=React.useRef(null);React.useEffect(()=>mountSettings(ref.current),[]);return React.createElement('div',{ref});}
    for(const metadata of [
      {name:'settings.section',id:'github-pixel',order:25,label:'像素主题'},
      {name:'plugins.bundle.config',key:ID}
    ]) scope.effect(()=>slots.inject(metadata.name,()=>slots.register(metadata,Settings)));
  }
  claudeFeatures=mountClaudeFeatures(ctx,()=>prefs);
  if(typeof ctx.inject==='function') {
    cleanup.push(ctx.inject(['configForms'],scope=>{scope.effect(()=>{bindSettings(scope);return()=>{offForm?.();offDirectory?.();offForm=null;offDirectory=null;form=null;};});}));
    cleanup.push(ctx.inject(['slots'],registerSlots));
    cleanup.push(ctx.inject(['theme'],scope=>{scope.effect(()=>{themeApi=service(scope,'theme');tokenSignature='';updateAppearance();const off=scope.on?.('theme/change',media);return()=>{off?.();tokenOff?.();tokenOff=null;themeApi=null;};});}));
  } else bindSettings(ctx);
  updateAppearance();
  return()=>{
    dead=true;observer.disconnect();themeObserver.disconnect();cancelAnimationFrame(reconcileFrame);offForm?.();offDirectory?.();
    document.removeEventListener('visibilitychange',visibility);systemDark.removeEventListener('change',media);reduced.removeEventListener('change',media);
    offDialog?.();dialog?.remove();launch.remove();claudeFeatures?.dispose();claudeFeatures=null;for(const field of fields.values()) field.dispose();fields.clear();listeners.clear();
    for(const fiber of cleanup) {try{fiber?.dispose?.();}catch{}}
    tokenOff?.();tokenOff=null;
    style.remove();for(const [name,value] of oldAttributes) if(value===null) root.removeAttribute(name);else root.setAttribute(name,value);
    for(const [name,[value,priority]] of oldProperties) if(value) root.style.setProperty(name,value,priority);else root.style.removeProperty(name);
  };
}
