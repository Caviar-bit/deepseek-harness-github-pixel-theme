import {createRequire} from 'node:module';
import {DEFAULTS, ID} from './preferences.js';
let schema = null;
for (const anchor of [process.argv[1], import.meta.url]) {
  try {
    const candidate = createRequire(anchor)('@deepseek-ai/schemastery');
    schema = candidate.default ?? candidate;
    if (typeof schema.object === 'function') break;
  } catch { /* The CLI-only host can activate without a settings service. */ }
}
let field = schema?.any?.().default({...DEFAULTS}).description('GitHub 像素主题外观与交互设置');
if (typeof field?.volatile === 'function') field = field.volatile();
export const name = ID;
export const Config = field ? schema.object({preferences: field}) : undefined;
export function apply(ctx) {
  if (typeof ctx.inject === 'function') ctx.inject(['settings'], scope => {
    if (typeof scope.settings?.configure === 'function') scope.effect(() => scope.settings.configure({auto:false},ctx.fiber));
  });
}
