export const ID = 'dsh-github-pixel-theme';
export const ENTRY = 'github-pixel-theme';
export const DEFAULTS = Object.freeze({
  enabled: true, mode: 'system', palette: 'github', accent: '#238636',
  cell: 10, lifetime: 300, intensity: 85, gridOpacity: 12,
  scope: 'home', trail: true, clickBurst: false, corners: true,
  motion: 'system', fps: 45, maxPixels: 96,
  fontSize: 15, font: 'system', contentWidth: 820, radius: 14,
  sidebar: 'soft', customLight: '#ffffff', customDark: '#0d1117',
  mainBackground: 'theme', cardBackground: 'auto',
  customSidebarLight: '#f6f8fa', customSidebarDark: '#10151c',
  customCardLight: '#ffffff', customCardDark: '#161b22',
  petStyle: 'claude', petScope: 'all', petSize: 100,
  runningStyle: 'claude', replySignatureStyle: 'claude', signatureScope: 'latest', starColor: '#d97757'
});
export const PALETTES = Object.freeze({
  github: {name: 'GitHub 原色', colors: ['#5fed83','#c898fd','#da7210','#8dd6ff','#0fbf3e','#5fb9ff','#08872b'], light: '#ffffff', dark: '#0d1117', accent: '#238636'},
  deepseek: {name: 'DeepSeek 蓝', colors: ['#4d6bfe','#80a7ff','#a5c7ff','#8dd6ff','#b6a0ff'], light: '#ffffff', dark: '#101827', accent: '#4d6bfe'},
  forest: {name: '森林', colors: ['#238636','#7bc96f','#52b788','#c5dfb0','#b8a46d'], light: '#f7faf5', dark: '#101a15', accent: '#238636'},
  dusk: {name: '暮色', colors: ['#a371f7','#c898fd','#f694c1','#8aa5ff','#ffb86b'], light: '#faf8ff', dark: '#191627', accent: '#8250df'},
  custom: {name: '自定义', colors: ['#238636','#80a7ff','#c898fd','#f2cc60'], light: '#ffffff', dark: '#0d1117', accent: '#238636'}
});
const CHOICES = {mode:['system','light','dark'],palette:Object.keys(PALETTES),scope:['home','all','off'],motion:['system','reduced'],font:['system','sans','mono'],sidebar:['soft','canvas','custom'],mainBackground:['theme','custom'],cardBackground:['auto','custom'],petStyle:['claude','none'],petScope:['home','all'],runningStyle:['claude','native'],replySignatureStyle:['claude','none'],signatureScope:['latest','all']};
const RANGES = {cell:[6,32],lifetime:[120,2000],intensity:[10,100],gridOpacity:[0,30],fps:[20,60],maxPixels:[24,240],fontSize:[12,20],contentWidth:[600,1280],radius:[0,24],petSize:[60,150]};
export function normalize(value) {
  const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const out = {...DEFAULTS};
  for (const key of Object.keys(out)) {
    if (key in CHOICES) {if (CHOICES[key].includes(source[key])) out[key] = source[key];}
    else if (key in RANGES) {if (typeof source[key] === 'number' && Number.isFinite(source[key])) out[key] = Math.round(Math.max(RANGES[key][0],Math.min(RANGES[key][1],source[key])));}
    else if (typeof out[key] === 'boolean') {if (typeof source[key] === 'boolean') out[key] = source[key];}
    else if (typeof source[key] === 'string' && /^#[0-9a-f]{6}$/i.test(source[key])) out[key] = source[key].toLowerCase();
  }
  return out;
}
export function readProfile(text) {
  if (text.length > 65536) throw new Error('配置文件过大，请选择本主题导出的 JSON。');
  const parsed = JSON.parse(text);
  if (parsed?.theme !== ID || parsed?.version !== 1 || !parsed.preferences || typeof parsed.preferences !== 'object' || Array.isArray(parsed.preferences)) throw new Error('不是本主题的有效配置文件。');
  return normalize(parsed.preferences);
}
const rgb = hex => [1,3,5].map(i=>parseInt(hex.slice(i,i+2),16));
export function mixColor(a,b,amount) {
  const first=rgb(a),second=rgb(b);
  return '#'+first.map((channel,i)=>Math.round(channel+(second[i]-channel)*amount).toString(16).padStart(2,'0')).join('');
}
export function contrastRatio(a,b) {
  const luminance=hex=>rgb(hex).map(c=>c/255).map(c=>c<=.04045?c/12.92:((c+.055)/1.055)**2.4).reduce((sum,c,i)=>sum+c*[.2126,.7152,.0722][i],0);
  const first=luminance(a),second=luminance(b);
  return (Math.max(first,second)+.05)/(Math.min(first,second)+.05);
}
export function surfaceTone(background) {
  let text=contrastRatio(background,'#1f2328')>=contrastRatio(background,'#e6edf3')?'#1f2328':'#e6edf3';
  if(contrastRatio(background,text)<4.5) text=contrastRatio(background,'#000000')>=contrastRatio(background,'#ffffff')?'#000000':'#ffffff';
  const dark=text==='#e6edf3'||text==='#ffffff';
  let muted=mixColor(background,text,.72);
  if(contrastRatio(background,muted)<4.5) muted=text;
  return {text,muted,border:mixColor(background,text,.2),dark};
}
export function resolveSurfaces(prefs,isDark) {
  const palette=PALETTES[prefs.palette];
  const custom=prefs.mainBackground==='custom'||prefs.palette==='custom';
  const bg=custom?(isDark?prefs.customDark:prefs.customLight):(isDark?palette.dark:palette.light);
  const main=surfaceTone(bg);
  const panel=custom?mixColor(bg,main.text,.045):(main.dark?'#161b22':'#f6f8fa');
  const card=prefs.cardBackground==='custom'?(isDark?prefs.customCardDark:prefs.customCardLight):(custom?mixColor(bg,main.text,.025):(main.dark?'#161b22':'#ffffff'));
  const sidebar=prefs.sidebar==='custom'?(isDark?prefs.customSidebarDark:prefs.customSidebarLight):prefs.sidebar==='canvas'?bg:custom?panel:(main.dark?'#10151c':'#f6f8fa');
  return {bg,panel,card,sidebar,main,cardTone:surfaceTone(card),sidebarTone:surfaceTone(sidebar)};
}
