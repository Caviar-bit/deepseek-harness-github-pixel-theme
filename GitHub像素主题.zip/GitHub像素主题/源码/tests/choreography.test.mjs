import {test} from 'node:test';
import assert from 'node:assert/strict';
import {ParticleChoreography,PARTICLE_BURST_DURATION,projectParticleOrb,projectParticleStage,isParticleSendControl} from '../src/particle-choreography.js';
import {normalize} from '../src/preferences.js';
test('composer gathers all particles, focus sustains the sphere, send releases to the field once',()=>{
 const s=new ParticleChoreography();s.engage(true,false);for(let i=0;i<70;i++)s.advance(1/60);assert.equal(s.advance(0),'orb');
 s.engage(false,true);assert.equal(s.advance(.1),'orb');assert.equal(s.send(2),true);assert.equal(s.send(2),false);
 assert.equal(s.advance(.2),'burst');s.advance(PARTICLE_BURST_DURATION);assert.equal(s.advance(.5),'field');assert.equal(s.amount,0);
 s.engage(false,true);assert.equal(s.advance(.5),'field','lingering editor focus cannot re-gather');s.input(true);assert.equal(s.advance(.5),'gather');
});
test('gather cancellation is continuous, and reduced motion bypasses choreography',()=>{
 const s=new ParticleChoreography();s.engage(true,false);s.advance(.3);const before=s.amount;s.engage(false,false);s.advance(.01);assert.ok(s.amount>0&&s.amount<before);
 s.send(0);assert.equal(s.advance(.1,false),'field');assert.equal(s.age,-1);assert.equal(s.amount,0);
});
test('3D projection rotates and deforms, has depth, and stays bounded',()=>{
 const p={orbY:.3,orbPhi:1.2,seed:.3,x:20,y:30};const a=projectParticleOrb(p,0,100),b=projectParticleOrb(p,1,100);
 assert.ok(Math.hypot(a.x-b.x,a.y-b.y)>5);assert.ok(Math.abs(Math.hypot(a.x,a.y)-Math.hypot(b.x,b.y))>1);
 for(let t=0;t<30;t+=.1){const q=projectParticleOrb(p,t,100);assert.ok(Number.isFinite(q.x)&&Math.hypot(q.x,q.y)<200);assert.ok(q.depth>=0&&q.depth<=1);}
});
test('explosion starts at the exact sphere position and returns continuously to the live field',()=>{
 const p={orbY:.3,orbPhi:1.2,seed:.3,x:20,y:30},center={x:400,y:260};
 const gathered=projectParticleStage(p,3,center,90,{amount:1,age:-1,startAmount:0,orbTime:3},1200,800);
 const start=projectParticleStage(p,3,center,90,{amount:1,age:0,startAmount:1,orbTime:3},1200,800);
 assert.equal(gathered.x,start.x);assert.equal(gathered.y,start.y);
 const flying=projectParticleStage(p,3.5,center,90,{amount:1,age:.5,startAmount:1,orbTime:3},1200,800);
 assert.ok(Math.hypot(flying.x-center.x,flying.y-center.y)>Math.hypot(start.x-center.x,start.y-center.y)+80);
 const end=projectParticleStage(p,6,center,90,{amount:0,age:2.8,startAmount:1,orbTime:3},1200,800);assert.equal(end.x,p.x);assert.equal(end.y,p.y);
});
test('send recognition excludes stop, disabled and in-flight controls, and scope stays independent',()=>{
 const button=(label,attrs={})=>({disabled:false,getAttribute:k=>k==='aria-label'?label:attrs[k]??null,hasAttribute:k=>k in attrs});
 assert.equal(isParticleSendControl(button('发送消息')),true);assert.equal(isParticleSendControl(button('Send message')),true);
 assert.equal(isParticleSendControl(button('停止生成')),false);assert.equal(isParticleSendControl(button('发送消息',{'data-sending':''})),false);
 assert.equal(isParticleSendControl({...button('发送消息'),disabled:true}),false);
 assert.equal(normalize({scope:'home'}).particleScope,'all');assert.equal(normalize({scope:'off'}).particleScope,'off');assert.equal(normalize({particleScope:'home',scope:'all'}).particleScope,'home');
});
